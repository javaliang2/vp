# 贡献指南

## 开发环境

```bash
npm install
cp .env.example .env   # 填好本地数据库和 R2 的连接信息
npx prisma migrate dev
npm run dev
```

## 提交前

```bash
npm run lint
npx tsc --noEmit
```

## 提交规范

没有强制要求，但建议 commit message 简明说清楚做了什么，比如：

```
feat: 支持后台可视化修改网站主题色
fix: 修复分页在分类筛选下的页码计算错误
```

## Pull Request

- 一个 PR 尽量只做一件事，方便 review
- 涉及数据库结构改动的，记得带上对应的 `prisma/migrations` 文件
