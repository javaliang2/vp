import { pinyin } from 'pinyin-pro';
import slugify from 'slugify';
import { randomBytes } from 'crypto';
import { prisma } from './db';

/**
 * 生成 URL 友好的 slug。
 *
 * 之前直接用 slugify(name, { strict: true })：strict 模式会把非拉丁字符（包括全部中文）
 * 当成非法字符滤掉。对于纯中文标题/分类名，这意味着生成的 slug 是空字符串 ""。
 * 这就是"第一个分类点进去等同于全部分类"、"第一个图集详情页 404"的根因：
 *   - 分类：/?category= 空值 → page.tsx 里 `categorySlug ? ... : null` 判断为假，等同没选分类
 *   - 图集：/albums/ 这个空 slug 段根本匹配不到 /albums/[slug] 动态路由，直接 404
 * 唯一性去重循环（while 查重）只在 baseSlug 已存在时才追加后缀，
 * 所以只有"第一次"生成空 slug 的那条记录会踩坑，后面重名的会拿到 "-1"、"-2" 这种后缀而侥幸正常。
 *
 * 修复：中文先转拼音，再 slugify，这样中文标题也能生成有意义、非空的 slug；
 * 如果转完仍是空的（比如纯 emoji、纯符号），兜底加一段随机字符，保证永远不为空。
 */
export function toSlug(input: string): string {
  const withPinyin = pinyin(input, { toneType: 'none', nonZh: 'consecutive' });
  const slug = slugify(withPinyin, { lower: true, strict: true });
  return slug || randomBytes(4).toString('hex');
}

// 图集详情页用的是扁平化 URL（域名/slug，见 app/[slug]/page.tsx），
// 这些名字被站点固定页面 / Next.js 的元数据文件约定占用了，撞上的话固定路由永远优先命中，
// 这个图集会变成永远打不开（只能通过 /albums/slug 老路径重定向过来，但重定向目标本身也是死的）。
// 创建图集时生成 slug要避开这些名字，见 app/api/monkey/albums/route.ts。
export const RESERVED_SLUGS = new Set([
  'search',
  'tags',
  'monkey',
  'about',
  'api',
  'robots.txt',
  'sitemap.xml',
  'icon',
  'apple-icon',
  'opengraph-image',
  'favicon.ico',
]);

// 标签名跟图集 slug 共用同一个扁平命名空间（都挂在 /[slug] 下），
// 所以标签名也要避开 RESERVED_SLUGS，还要避开"跟任何已存在图集的 slug 重名"——
// 撞上任意一种，/[slug] 页面里"先查图集再查标签"的逻辑都会导致这个标签被永远吞掉、打不开，
// 而且不会报错，后台看着标签还在，前台就是死链接。
// 建/改图集的 tags 字段、以及标签改名接口，都要在落库前调用这个函数做校验。
//
// excludeAlbumId：编辑图集自身的 tags 时，如果标签名恰好等于"这个图集自己的 slug"，
// 不算冲突（打开 /slug 本来就会先命中它自己，行为符合预期），所以要把自身排除掉。
export async function findConflictingTag(
  tags: string[],
  excludeAlbumId?: string,
): Promise<string | null> {
  for (const tag of tags) {
    if (RESERVED_SLUGS.has(tag)) return tag;
  }
  if (tags.length === 0) return null;

  const collision = await prisma.album.findFirst({
    where: {
      slug: { in: tags },
      ...(excludeAlbumId ? { id: { not: excludeAlbumId } } : {}),
    },
    select: { slug: true },
  });
  return collision?.slug ?? null;
}
