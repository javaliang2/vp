import { pinyin } from 'pinyin-pro';
import slugify from 'slugify';
import { randomBytes } from 'crypto';

/**
 * 生成 URL 友好的 slug。
 *
 * 之前直接用 slugify(name, { strict: true })：strict 模式会把非拉丁字符（包括全部中文）
 * 当成非法字符滤掉。对于纯中文标题/分类名，这意味着生成的 slug 是空字符串 ""。
 * 这就是"第一个分类点进去等同于全部分类"、"第一个图集详情页 404"的根因：
 *   - 分类：/?category= 空值 → page.tsx 里 `categorySlug ? ... : null` 判断为假，等同没选分类
 *   - 图集：/albums/ 这个空 slug 段根本匹配不到 /albums/[slug] 动态路由，直接 404
 * 唯一性去重循环（while 查重）只在 baseSlug 已存在时才追加后缀，
 * 所以只有"第一次"生成空 slug 的那条记录会踩坑，后面重名的会拿到 "-1"、"-2" 这种后缀而侥幸正常。
 *
 * 修复：中文先转拼音，再 slugify，这样中文标题也能生成有意义、非空的 slug；
 * 如果转完仍是空的（比如纯 emoji、纯符号），兜底加一段随机字符，保证永远不为空。
 */
export function toSlug(input: string): string {
  const withPinyin = pinyin(input, { toneType: 'none', nonZh: 'consecutive' });
  const slug = slugify(withPinyin, { lower: true, strict: true });
  return slug || randomBytes(4).toString('hex');
}
