import { prisma } from '@/lib/db';

export type TagCount = { tag: string; count: number };

// tags 是数组字段，Prisma 的 groupBy 没法直接按数组元素分组统计，
// 用 unnest() 把每个图集的 tags 数组拆成一行行的 tag 再 group by，走原生 SQL。
// FROM 列表里的 unnest(...) 隐式就是 LATERAL 的，可以直接引用前面 "Album" 表的列。
//
// onlyPublished=true（前台用）只统计已发布图集；false（后台管理用）统计全部，
// 包括草稿，不然草稿上打的标签在后台管理页面里看不到、也没法重命名/删除。
export async function getTagCounts(onlyPublished: boolean): Promise<TagCount[]> {
  if (onlyPublished) {
    return prisma.$queryRaw<TagCount[]>`
      SELECT tag, COUNT(*)::int AS count
      FROM "Album", unnest("Album"."tags") AS tag
      WHERE "Album"."status" = 'PUBLISHED'
      GROUP BY tag
      ORDER BY count DESC, tag ASC
    `;
  }
  return prisma.$queryRaw<TagCount[]>`
    SELECT tag, COUNT(*)::int AS count
    FROM "Album", unnest("Album"."tags") AS tag
    GROUP BY tag
    ORDER BY tag ASC
  `;
}
