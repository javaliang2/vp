import type { NextRequest } from 'next/server';

// 部署在 WireGuard 内网、由 Caddy/Nginx 反代到本机端口，反代通常会设 x-real-ip；
// 没有的话退回 x-forwarded-for 的第一段（离用户最近的那一跳）。都拿不到就归为 'unknown'，
// 限流时 'unknown' 会被当成同一个桶处理，不影响真实 IP 的限流额度。
export function getClientIp(req: NextRequest): string {
  return req.headers.get('x-real-ip') || req.headers.get('x-forwarded-for')?.split(',')[0].trim() || 'unknown';
}
