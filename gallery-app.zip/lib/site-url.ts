// 统一从这里取站点的公开访问地址（不带结尾斜杠）。
// sitemap.xml / robots.txt / canonical URL / OG url 都依赖这个值，
// 没配的话用相对路径场景下的兜底值，但生产环境一定要在 .env 里设置 SITE_URL。
export function siteUrl(): string {
  const raw = process.env.SITE_URL || process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';
  return raw.replace(/\/+$/, '');
}
