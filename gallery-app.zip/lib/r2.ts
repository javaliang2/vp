import { S3Client, PutObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

// R2 兼容 S3 API，endpoint 格式：https://<accountId>.r2.cloudflarestorage.com
export const r2 = new S3Client({
  region: 'auto',
  endpoint: process.env.R2_ENDPOINT!,
  credentials: {
    accessKeyId: process.env.R2_ACCESS_KEY_ID!,
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY!,
  },
});

const BUCKET = process.env.R2_BUCKET!;

/** 生成一个用于前端直传的预签名 URL，有效期默认 5 分钟 */
export async function createUploadUrl(key: string, contentType: string, expiresIn = 300) {
  const command = new PutObjectCommand({
    Bucket: BUCKET,
    Key: key,
    ContentType: contentType,
  });
  return getSignedUrl(r2, command, { expiresIn });
}

export async function deleteObject(key: string) {
  await r2.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: key }));
}

/** 拼出公开访问 URL（需要在 R2 bucket 开启公开访问或绑定自定义域名） */
export function publicUrl(key: string) {
  const base = process.env.R2_PUBLIC_URL!; // 例如 https://images.yourdomain.com
  return `${base.replace(/\/$/, '')}/${key}`;
}
