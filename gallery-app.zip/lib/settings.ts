import { prisma } from '@/lib/db';
import { redis } from '@/lib/redis';

export type SiteSettings = {
  siteTitle: string;
  siteDescription: string;
  logoKey: string | null;
  backgroundColor: string;
  textColor: string;
  accentColor: string;
  icpNumber: string;
  contactInfo: string;
  aboutContent: string;
};

const DEFAULTS: SiteSettings = {
  siteTitle: 'Gallery',
  siteDescription: '一个简单的图集展示站',
  logoKey: null,
  backgroundColor: '#1e1e1e',
  textColor: '#f2f2f0',
  accentColor: '#ffffff',
  icpNumber: '',
  contactInfo: '',
  aboutContent: '',
};

// 根 layout 里每个页面都会调一次 getSiteSettings，这是全站请求量最大的一个查询。
// 用 Redis 缓存一份，TTL 给得比较短（够用就行，不追求"改了设置立刻全局生效"，
// 后台保存时会主动 del 这个 key，配合 revalidatePath 做到基本即时生效）。
// 没配 REDIS_URL，或者 Redis 抖了，都直接退回原来的查库逻辑，不影响正常访问。
const CACHE_KEY = 'gallery:settings';
const CACHE_TTL_SEC = 300;

export async function getSiteSettings(): Promise<SiteSettings> {
  if (redis) {
    try {
      const cached = await redis.get(CACHE_KEY);
      if (cached) return JSON.parse(cached) as SiteSettings;
    } catch (err) {
      console.error('[settings] redis read failed, falling back to db:', err);
    }
  }

  const settings = await (async () => {
    try {
      const row = await prisma.siteSetting.findUnique({ where: { id: 1 } });
      return row ? { ...DEFAULTS, ...row } : DEFAULTS;
    } catch {
      // 表还没迁移到、或者查询失败时兜底，不影响页面渲染
      return DEFAULTS;
    }
  })();

  if (redis) {
    redis.set(CACHE_KEY, JSON.stringify(settings), 'EX', CACHE_TTL_SEC).catch((err) => {
      // 写缓存失败不影响这次请求，本来就查到数据了；下次请求会再查一次库，问题不大
      console.error('[settings] redis write failed:', err);
    });
  }

  return settings;
}

// 后台保存设置之后调用，让下一次请求立刻拿到新数据，不用等 TTL 过期。
export async function invalidateSiteSettingsCache(): Promise<void> {
  if (!redis) return;
  try {
    await redis.del(CACHE_KEY);
  } catch (err) {
    console.error('[settings] redis cache invalidation failed:', err);
  }
}
