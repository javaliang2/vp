-- 1) 搜索性能：给 title/description 建三元组(trigram)索引，加速现有的 ILIKE '%xxx%' 模糊搜索。
--    对中文这类没有空格分词的文本，trigram 比 Postgres 自带的全文搜索(tsvector)更合适，
--    不依赖分词字典，且 Postgres 能自动用它加速现有的 contains/ILIKE 查询，不用改任何查询代码。
CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE INDEX IF NOT EXISTS "Album_title_trgm_idx" ON "Album" USING GIN ("title" gin_trgm_ops);
CREATE INDEX IF NOT EXISTS "Album_description_trgm_idx" ON "Album" USING GIN ("description" gin_trgm_ops);

-- tags 是数组字段，has/hasSome 这类包含查询用 GIN 索引能加速
CREATE INDEX IF NOT EXISTS "Album_tags_gin_idx" ON "Album" USING GIN ("tags");

-- 2) 图片加载体验：LQIP 模糊占位图
ALTER TABLE "Photo" ADD COLUMN "blurDataURL" TEXT;
ALTER TABLE "Album" ADD COLUMN "coverBlurDataURL" TEXT;
