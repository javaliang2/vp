-- logo 的 base64 数据单独存一张表，不跟高频查询的 SiteSetting 混在一起，
-- 避免每个页面渲染都要带上这份图片数据。
CREATE TABLE "SiteAsset" (
    "id" INTEGER NOT NULL DEFAULT 1,
    "logoData" TEXT,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "SiteAsset_pkey" PRIMARY KEY ("id")
);
