#!/bin/sh
set -e

echo "正在执行数据库迁移…"
node_modules/.bin/prisma migrate deploy

echo "启动应用…"
exec "$@"
