#!/bin/bash
# 首次在新 VPS 上部署，从零到能访问网站。
# 用法：在项目根目录下执行 ./scripts/first-deploy.sh
set -e

BLUE='\033[0;34m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${BLUE}▸${NC} $1"; }
ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}!${NC} $1"; }
err()  { echo -e "${RED}✗${NC} $1"; }

# 跟 pg-redis-shared.sh / infra-shared.sh 保持一致的写法，探测本机 WireGuard 网卡的 IP。
# 多节点部署时，每个节点跑一次 first-deploy.sh，各自把自己的 WG_IP 写进本地 .env，
# web 容器就只监听这个节点的 WireGuard 内网地址，配合 nginx-gateway.sh 在网关节点做负载均衡。
get_wg_ip() {
  local wg_iface="${WG_IFACE:-wg0}" ip
  ip=$(ip addr show "${wg_iface}" 2>/dev/null \
      | awk '/inet /{gsub(/\/.*/, "", $2); print $2; exit}')
  echo "$ip"
}

# ---- 1. 检查/安装 Docker ----
if ! command -v docker &> /dev/null; then
  log "没检测到 Docker，开始安装…"
  curl -fsSL https://get.docker.com | sh
  sudo usermod -aG docker "$USER"
  warn "Docker 组权限刚加上，如果下面的命令报权限错误，请退出重新 SSH 登录一次再重跑这个脚本"
else
  ok "Docker 已安装"
fi

if ! docker compose version &> /dev/null; then
  err "docker compose 插件不可用，请手动检查 Docker 安装（较新版本一般自带）"
  exit 1
fi
ok "docker compose 可用"

# ---- 1.5 检查/安装 aws-cli（备份脚本用它做异地备份，可选但顺手装上） ----
if command -v aws &> /dev/null; then
  ok "aws-cli 已安装"
else
  log "没检测到 aws-cli，尝试自动安装（用于 backup.sh 的异地备份，装不上也不影响本次部署）…"
  if command -v apt-get &> /dev/null; then
    sudo apt-get update -qq && sudo apt-get install -y -qq awscli
  elif command -v pip3 &> /dev/null; then
    pip3 install --quiet awscli
  fi

  if command -v aws &> /dev/null; then
    ok "aws-cli 安装完成"
  else
    warn "aws-cli 自动安装失败，不影响当前部署。之后想要异地备份的话手动装一下："
    echo "    sudo apt install -y awscli   # 或 pip install awscli"
  fi
fi

# ---- 1.6 检查/安装 postgresql-client（backup.sh/restore.sh 用它的 pg_dump/psql 连远程共享库，
#          应用本身走 Prisma 连库不需要这个，只有想用备份/恢复脚本时才用得上，可选但顺手装上） ----
if command -v pg_dump &> /dev/null && command -v psql &> /dev/null; then
  ok "postgresql-client 已安装"
else
  log "没检测到 pg_dump/psql，尝试自动安装（用于 backup.sh/restore.sh，装不上也不影响本次部署）…"
  if command -v apt-get &> /dev/null; then
    sudo apt-get update -qq && sudo apt-get install -y -qq postgresql-client
  fi

  if command -v pg_dump &> /dev/null && command -v psql &> /dev/null; then
    ok "postgresql-client 安装完成"
  else
    warn "postgresql-client 自动安装失败，不影响当前部署。之后想要用备份/恢复脚本的话手动装一下："
    echo "    sudo apt install -y postgresql-client"
  fi
fi

# ---- 2. 准备 .env ----
if [ ! -f .env ]; then
  log "没有 .env，从 .env.example 创建一份"
  cp .env.example .env

  # 会话密钥自动生成，省得手动跑 openssl
  AUTH_SECRET=$(openssl rand -base64 32)
  sed -i.bak "s#^AUTH_SECRET=.*#AUTH_SECRET=${AUTH_SECRET}#" .env
  rm -f .env.bak
  ok "已自动生成会话密钥"

  # ---- 数据库：连接 pg-redis-shared.sh 部署的共享库（走 WireGuard 内网） ----
  echo
  log "配置数据库连接（先去共享库那台机器上执行一次，拿到库名/用户/密码：）"
  echo "    ./pg-redis-shared.sh add-db /srv/pg-infra gallery gallery"
  echo "  不确定密码的话，也可以用 list-db 查看，或者重新跑 add-db 传第4个参数指定密码"
  echo

  read -rp "共享库所在机器的 WireGuard IP: " DB_WG_IP_INPUT
  read -rp "数据库密码（add-db 生成/指定的那个）: " DB_PASS_INPUT

  if [ -n "$DB_WG_IP_INPUT" ] && [ -n "$DB_PASS_INPUT" ]; then
    sed -i.bak "s#^DATABASE_URL=.*#DATABASE_URL=postgresql://gallery:${DB_PASS_INPUT}@${DB_WG_IP_INPUT}:5432/gallery#" .env
    rm -f .env.bak
    ok "数据库连接已写入 .env"
  else
    warn "数据库连接信息不完整，先跳过。之后手动编辑 .env 里的 DATABASE_URL 再启动，确保本机已连上 WireGuard mesh 能通到共享库"
  fi

  # ---- 本机 WireGuard IP：多节点部署时，web 容器只监听这个地址 ----
  echo
  MY_WG_IP=$(get_wg_ip)
  if [ -n "$MY_WG_IP" ]; then
    sed -i.bak "s#^\# WG_IP=.*#WG_IP=${MY_WG_IP}#" .env
    rm -f .env.bak
    ok "检测到本机 WireGuard IP: ${MY_WG_IP}，已写入 .env（web 容器将只监听这个地址）"
    warn "如果这是单节点部署、不打算用 nginx-gateway.sh 做多节点负载均衡，可以把 .env 里的 WG_IP 这行删掉/注释掉，回退成绑 127.0.0.1"

    echo
    log "配置 Redis（可选，多节点部署时用于跨节点共享限流；单节点部署直接回车跳过即可）"
    read -rp "共享 Redis 所在机器的 WireGuard IP（留空跳过；通常跟数据库同一台: ${DB_WG_IP_INPUT:-未设置}）: " REDIS_WG_IP_INPUT
    if [ -n "$REDIS_WG_IP_INPUT" ]; then
      read -rp "Redis 密码: " REDIS_PASS_INPUT
    fi

    if [ -n "$REDIS_WG_IP_INPUT" ] && [ -n "$REDIS_PASS_INPUT" ]; then
      sed -i.bak "s#^\# REDIS_URL=.*#REDIS_URL=redis://:${REDIS_PASS_INPUT}@${REDIS_WG_IP_INPUT}:6379#" .env
      rm -f .env.bak
      ok "Redis 连接已写入 .env"
    else
      warn "跳过 Redis 配置，单节点部署不影响；多节点部署的话之后手动编辑 .env 里的 REDIS_URL"
    fi
  else
    warn "没检测到 ${WG_IFACE:-wg0} 网卡，跳过 WG_IP 自动写入。单节点部署不影响，.env 会回退绑 127.0.0.1；多节点部署的话请先确认 WireGuard 已连上再重跑"
  fi

  # ---- R2 配置，交互式输入 ----
  echo
  log "接下来配置 Cloudflare R2（去 Cloudflare Dashboard → R2 → 管理 API 令牌 拿这几项）"
  echo "  不确定的话可以先留空，回车跳过，之后自己手动编辑 .env 再补上"
  echo

  read -rp "R2_ENDPOINT (形如 https://<account-id>.r2.cloudflarestorage.com): " R2_ENDPOINT_INPUT
  read -rp "R2_ACCESS_KEY_ID: " R2_ACCESS_KEY_INPUT
  read -rp "R2_SECRET_ACCESS_KEY: " R2_SECRET_KEY_INPUT
  read -rp "R2_BUCKET (bucket 名称): " R2_BUCKET_INPUT
  read -rp "R2_PUBLIC_URL (公开访问域名，形如 https://images.yourdomain.com): " R2_PUBLIC_URL_INPUT

  # 只有实际输入了内容才写进 .env，避免把已有的占位符值清空成空字符串
  [ -n "$R2_ENDPOINT_INPUT" ] && sed -i.bak "s#^R2_ENDPOINT=.*#R2_ENDPOINT=${R2_ENDPOINT_INPUT}#" .env
  [ -n "$R2_ACCESS_KEY_INPUT" ] && sed -i.bak "s#^R2_ACCESS_KEY_ID=.*#R2_ACCESS_KEY_ID=${R2_ACCESS_KEY_INPUT}#" .env
  [ -n "$R2_SECRET_KEY_INPUT" ] && sed -i.bak "s#^R2_SECRET_ACCESS_KEY=.*#R2_SECRET_ACCESS_KEY=${R2_SECRET_KEY_INPUT}#" .env
  [ -n "$R2_BUCKET_INPUT" ] && sed -i.bak "s#^R2_BUCKET=.*#R2_BUCKET=${R2_BUCKET_INPUT}#" .env
  if [ -n "$R2_PUBLIC_URL_INPUT" ]; then
    sed -i.bak "s#^R2_PUBLIC_URL=.*#R2_PUBLIC_URL=${R2_PUBLIC_URL_INPUT}#" .env
    # next.config.js 用这个校验图片域名，自动从 URL 里把域名部分抠出来
    R2_HOSTNAME=$(echo "$R2_PUBLIC_URL_INPUT" | sed -E 's#^https?://##' | cut -d'/' -f1)
    sed -i.bak "s#^R2_PUBLIC_HOSTNAME=.*#R2_PUBLIC_HOSTNAME=${R2_HOSTNAME}#" .env
  fi
  rm -f .env.bak

  if [ -z "$R2_ENDPOINT_INPUT" ] || [ -z "$R2_ACCESS_KEY_INPUT" ] || [ -z "$R2_SECRET_KEY_INPUT" ] || [ -z "$R2_BUCKET_INPUT" ]; then
    warn "R2 配置不完整，图片上传功能现在用不了。之后想起来了手动编辑 .env 补上，改完记得跑："
    echo "    docker compose up -d --build"
  else
    ok "R2 配置已写入 .env"
  fi
else
  ok ".env 已存在，跳过生成"
fi

# ---- 3. 构建并启动 ----
log "构建镜像并启动服务（第一次会比较慢，耐心等下）…"
docker compose up -d --build

log "等待数据库和应用就绪…"
sleep 5
for i in $(seq 1 12); do
  if docker compose exec -T web node -e "
    require('http').get('http://localhost:3000', res => {
      process.exit(res.statusCode === 200 ? 0 : 1);
    }).on('error', () => process.exit(1));
  " 2>/dev/null; then
    ok "应用已经能响应了"
    break
  fi
  if [ "$i" -eq 12 ]; then
    warn "等了一分钟还没就绪，去看看日志：docker compose logs -f web"
  fi
  sleep 5
done

# ---- 4. 创建管理员账号 ----
echo
log "接下来创建管理员账号"
read -rp "管理员邮箱: " ADMIN_EMAIL
read -rp "管理员密码（至少10位，包含字母和数字）: " ADMIN_PASS

if docker compose exec -T web node prisma/create-admin.cjs "$ADMIN_EMAIL" "$ADMIN_PASS"; then
  ok "管理员账号创建成功"
else
  err "创建失败，密码可能不满足强度要求，重跑一次："
  echo "  docker compose exec web node prisma/create-admin.cjs <email> <password>"
fi

# ---- 5. 完成 ----
echo
ok "部署完成！"
warn "3000 端口只绑在了 127.0.0.1 上，不对公网暴露（Docker 发布端口会绕过 ufw 规则，所以干脆不监听公网接口），VPS 的 IP:3000 是访问不了的，这是有意为之。"
echo "  先测试的话，两种办法："
echo "    1. 在 VPS 上直接跑：curl http://localhost:3000"
echo "    2. 本地执行：ssh -L 3000:localhost:3000 你的VPS，然后浏览器打开 http://localhost:3000"
echo
echo "  正式使用前记得："
echo "    1. 配置域名 + Caddy/Nginx 反代和 HTTPS（反代进程跑在 VPS 上，通过 localhost:3000 连到容器）"
echo "    2. 用 ufw 只放行 22/80/443（3000 本来就没对外开，这步主要是防其他服务）"
