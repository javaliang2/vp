import { getCategoryTree } from '@/lib/categories';
import CategoryForm from './CategoryForm';
import DeleteCategoryButton from './DeleteCategoryButton';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default async function CategoriesPage() {
  const tree = await getCategoryTree();
  const albumCounts = await prisma.album.groupBy({
    by: ['categoryId'],
    _count: true,
  });
  const countMap = new Map(albumCounts.map((a) => [a.categoryId, a._count]));

  const topLevel = tree.map((c) => ({ id: c.id, name: c.name }));

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <h1 className="mb-6 text-xl">分类管理</h1>

      <CategoryForm topLevelCategories={topLevel} />

      <div className="mt-8 space-y-6">
        {tree.map((top) => (
          <div key={top.id}>
            <div className="flex items-center justify-between border-b border-[var(--fg-20)] py-2">
              <span className="font-medium">{top.name}</span>
              <div className="flex items-center gap-3 text-sm text-[var(--fg-50)]">
                <span>{countMap.get(top.id) || 0} 个图集</span>
                <DeleteCategoryButton id={top.id} />
              </div>
            </div>
            {top.children.length > 0 ? (
              <ul className="ml-4 mt-1">
                {top.children.map((child) => (
                  <li
                    key={child.id}
                    className="flex items-center justify-between border-b border-[var(--fg-10)] py-2 text-sm"
                  >
                    <span className="text-[var(--fg-80)]">└ {child.name}</span>
                    <div className="flex items-center gap-3 text-[var(--fg-50)]">
                      <span>{countMap.get(child.id) || 0} 个图集</span>
                      <DeleteCategoryButton id={child.id} />
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="ml-4 mt-1 py-2 text-sm text-[var(--fg-30)]">还没有子分类</p>
            )}
          </div>
        ))}
      </div>

      {tree.length === 0 && (
        <p className="py-8 text-center text-[var(--fg-50)]">还没有分类，先在上面新建一个吧</p>
      )}
    </div>
  );
}
