import { prisma } from '@/lib/db';
import Link from 'next/link';
import DeleteButton from './DeleteButton';

export const dynamic = 'force-dynamic'; // 后台不缓存，实时看最新数据

export default async function AdminDashboard() {
  const albums = await prisma.album.findMany({
    orderBy: { createdAt: 'desc' },
    include: {
      _count: { select: { photos: true } },
      category: { select: { name: true, parent: { select: { name: true } } } },
    },
  });

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-xl">图集管理</h1>
        <Link
          href="/monkey/albums/new"
          style={{ backgroundColor: 'var(--accent-color)' }}
          className="rounded px-4 py-2 text-center text-sm text-[var(--accent-contrast)]"
        >
          + 新建图集
        </Link>
      </div>

      {/* 窄屏：卡片列表 */}
      <div className="space-y-3 sm:hidden">
        {albums.map((album) => (
          <div key={album.id} className="rounded border border-[var(--fg-10)] p-4">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-medium">{album.title}</p>
                <p className="mt-1 text-xs text-[var(--fg-50)]">
                  {album.category
                    ? `${album.category.parent ? album.category.parent.name + ' / ' : ''}${album.category.name}`
                    : '未分类'}
                </p>
              </div>
              <div className="flex items-center gap-3">
                {album.status === 'PUBLISHED' && (
                  <a
                    href={`/${album.slug}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[var(--fg-50)] hover:text-[var(--text-color)]"
                  >
                    预览
                  </a>
                )}
                <Link
                  href={`/monkey/albums/${album.id}/edit`}
                  className="text-[var(--fg-50)] hover:text-[var(--text-color)]"
                >
                  编辑
                </Link>
                <DeleteButton id={album.id} />
              </div>
            </div>
            <div className="mt-3 flex gap-4 text-xs text-[var(--fg-50)]">
              <span>{album.status === 'PUBLISHED' ? '已发布' : '草稿'}</span>
              <span>{album._count.photos} 张图片</span>
              <span>{album.viewCount} 次浏览</span>
            </div>
          </div>
        ))}
      </div>

      {/* 宽屏：表格 */}
      <table className="hidden w-full text-left text-sm sm:table">
        <thead className="border-b border-[var(--fg-20)] text-[var(--fg-50)]">
          <tr>
            <th className="py-2">标题</th>
            <th>分类</th>
            <th>状态</th>
            <th>图片数</th>
            <th>浏览量</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {albums.map((album) => (
            <tr key={album.id} className="border-b border-[var(--fg-10)]">
              <td className="py-3">{album.title}</td>
              <td className="text-[var(--fg-60)]">
                {album.category ? `${album.category.parent ? album.category.parent.name + ' / ' : ''}${album.category.name}` : '—'}
              </td>
              <td>{album.status === 'PUBLISHED' ? '已发布' : '草稿'}</td>
              <td>{album._count.photos}</td>
              <td>{album.viewCount}</td>
              <td className="text-right">
                <div className="flex items-center justify-end gap-3">
                  {album.status === 'PUBLISHED' && (
                    <a
                      href={`/${album.slug}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[var(--fg-50)] hover:text-[var(--text-color)]"
                    >
                      预览
                    </a>
                  )}
                  <Link
                    href={`/monkey/albums/${album.id}/edit`}
                    className="text-[var(--fg-50)] hover:text-[var(--text-color)]"
                  >
                    编辑
                  </Link>
                  <DeleteButton id={album.id} />
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {albums.length === 0 && <p className="py-8 text-center text-[var(--fg-50)]">还没有图集，点右上角新建一个吧</p>}
    </div>
  );
}
