// 图片压缩 + 上传到 R2 的共享逻辑，新建图集页、编辑图集页都用这一份。
// 只能在浏览器端用（用到了 createImageBitmap / canvas / document），
// 只允许被 'use client' 组件 import。

// 超过这个体积（字节）才压缩原图，没超过就原样上传，不瞎折腾
export const COMPRESS_THRESHOLD_BYTES = 5 * 1024 * 1024; // 5MB
// 压缩时长边最多缩到这么大（像素），保持宽高比
export const COMPRESS_MAX_DIMENSION = 2560;
// 压缩输出质量（webp，0~1）
export const COMPRESS_QUALITY = 0.85;
// LQIP 模糊占位图的长边（像素）：故意压得很小，肉眼看不出细节，
// 只用来在真图加载完成前撑个色块过渡，体积够小才能直接内嵌进页面 HTML 里
const BLUR_PLACEHOLDER_MAX_DIMENSION = 16;
const BLUR_PLACEHOLDER_QUALITY = 0.5;

// 用 canvas 把图片缩放到指定长边、按给定格式/质量重新编码
async function drawToBlob(
  img: ImageBitmap,
  maxSize: number,
  type: string,
  quality: number,
): Promise<{ blob: Blob; width: number; height: number }> {
  const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
  const w = Math.round(img.width * scale);
  const h = Math.round(img.height * scale);
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  ctx.drawImage(img, 0, 0, w, h);
  const blob: Blob = await new Promise((resolve) => canvas.toBlob((b) => resolve(b!), type, quality));
  return { blob, width: w, height: h };
}

// 生成一张几像素大小的模糊占位图，直接编码成 base64 data URI（不用传 R2，体积小到可以内嵌）
async function drawBlurDataURL(img: ImageBitmap): Promise<string> {
  const scale = Math.min(1, BLUR_PLACEHOLDER_MAX_DIMENSION / Math.max(img.width, img.height));
  const w = Math.max(1, Math.round(img.width * scale));
  const h = Math.max(1, Math.round(img.height * scale));
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  ctx.drawImage(img, 0, 0, w, h);
  return canvas.toDataURL('image/jpeg', BLUR_PLACEHOLDER_QUALITY);
}

// 一次性把一张源文件处理成「缩略图」+「要上传的原图」：
// - 缩略图固定压到 600px webp，给首页封面/网格用；
// - "原图"默认就是用户选的文件本身，不动；只有体积超过 COMPRESS_THRESHOLD_BYTES
//   才会走跟缩略图一样的 canvas 缩放+重新编码流程（长边压到 COMPRESS_MAX_DIMENSION）。
//   注意压缩后实际尺寸会变，返回的 width/height 是最终真正上传的那份图的尺寸，
//   不是原始源文件的尺寸——这样详情页用这个尺寸做布局占位才不会跟真实图片对不上。
export async function processImage(file: File): Promise<{
  thumbBlob: Blob;
  blurDataURL: string;
  original: { blob: Blob; width: number; height: number; filename: string; contentType: string };
}> {
  const img = await createImageBitmap(file);
  const thumb = await drawToBlob(img, 600, 'image/webp', 0.85);
  const blurDataURL = await drawBlurDataURL(img);

  if (file.size > COMPRESS_THRESHOLD_BYTES) {
    const compressed = await drawToBlob(img, COMPRESS_MAX_DIMENSION, 'image/webp', COMPRESS_QUALITY);
    return {
      thumbBlob: thumb.blob,
      blurDataURL,
      original: {
        blob: compressed.blob,
        width: compressed.width,
        height: compressed.height,
        filename: file.name.replace(/\.\w+$/, '.webp'),
        contentType: 'image/webp',
      },
    };
  }

  return {
    thumbBlob: thumb.blob,
    blurDataURL,
    original: { blob: file, width: img.width, height: img.height, filename: file.name, contentType: file.type },
  };
}

export async function uploadToR2(file: Blob, filename: string, contentType: string, kind: 'original' | 'thumb') {
  const res = await fetch('/api/monkey/upload-url', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ filename, contentType, kind }),
  });
  const { uploadUrl, key } = await res.json();
  await fetch(uploadUrl, { method: 'PUT', headers: { 'Content-Type': contentType }, body: file });
  return key as string;
}

// 上传一整张图（压缩+原图+缩略图都传好），返回可以直接塞进 photos 数组的对象
export async function uploadPhoto(file: File, altText: string) {
  const { thumbBlob, blurDataURL, original } = await processImage(file);
  const [r2Key, thumbKey] = await Promise.all([
    uploadToR2(original.blob, original.filename, original.contentType, 'original'),
    uploadToR2(thumbBlob, file.name.replace(/\.\w+$/, '.webp'), 'image/webp', 'thumb'),
  ]);
  return { r2Key, thumbKey, width: original.width, height: original.height, altText, blurDataURL };
}
