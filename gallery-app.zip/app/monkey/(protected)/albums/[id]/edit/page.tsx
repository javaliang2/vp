import { prisma } from '@/lib/db';
import { publicUrl } from '@/lib/r2';
import { notFound } from 'next/navigation';
import EditAlbumForm from './EditAlbumForm';

export const dynamic = 'force-dynamic'; // 后台不缓存，实时看最新数据

export default async function EditAlbumPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;

  const album = await prisma.album.findUnique({
    where: { id },
    include: {
      photos: { orderBy: { sortOrder: 'asc' } },
      category: { select: { id: true, parentId: true } },
    },
  });
  if (!album) notFound();

  const categories = await prisma.category.findMany({
    orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
    select: { id: true, name: true, parentId: true },
  });

  // 二级分类下拉框需要的两个值：
  // - 分类是顶级分类：parentCategoryId = 分类自己的 id，categoryId 留空（"不选子分类"）
  // - 分类是子分类：parentCategoryId = 它的父级 id，categoryId = 它自己
  const cat = album.category;
  const parentCategoryId = cat ? (cat.parentId ?? cat.id) : '';
  const categoryId = cat && cat.parentId ? cat.id : '';

  const photos = album.photos.map((p) => ({
    id: p.id,
    thumbUrl: publicUrl(p.thumbKey),
    thumbKey: p.thumbKey,
    width: p.width,
    height: p.height,
  }));

  return (
    <EditAlbumForm
      album={{
        id: album.id,
        title: album.title,
        description: album.description ?? '',
        tags: album.tags.join(', '),
        status: album.status,
        categoryId,
        parentCategoryId,
        coverKey: album.coverKey ?? '',
      }}
      categories={categories}
      initialPhotos={photos}
    />
  );
}
