import { ImageResponse } from 'next/og';
import { getSiteSettings } from '@/lib/settings';
import { getContrastTextColor } from '@/lib/color';
import { getLogoDataUri } from '@/lib/site-asset';

export const runtime = 'nodejs';
export const revalidate = 3600;

export const size = { width: 180, height: 180 };
export const contentType = 'image/png';

export default async function AppleIcon() {
  const [settings, logoDataUri] = await Promise.all([getSiteSettings(), getLogoDataUri()]);

  if (logoDataUri) {
    const logoSize = Math.round(size.width * 0.7);
    try {
      return new ImageResponse(
        (
          <div
            style={{
              width: size.width,
              height: size.height,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              background: settings.accentColor,
            }}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={logoDataUri} width={logoSize} height={logoSize} style={{ objectFit: 'contain' }} />
          </div>
        ),
        { ...size },
      );
    } catch {
      // satori 渲染这张图失败了（比如图片格式它不认），别让整个 favicon 请求直接 500，退回文字版
    }
  }

  // 没设置 logo 时，退回到取站点标题首字的兜底方案
  const letter = (settings.siteTitle?.trim()?.[0] || '图').toUpperCase();
  const textColor = getContrastTextColor(settings.accentColor);

  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: settings.accentColor,
          color: textColor,
          fontSize: 96,
          fontWeight: 600,
        }}
      >
        {letter}
      </div>
    ),
    { ...size },
  );
}
