import { cache } from 'react';
import { prisma } from '@/lib/db';
import { publicUrl } from '@/lib/r2';
import Image from 'next/image';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { getSiteSettings } from '@/lib/settings';
import { siteUrl } from '@/lib/site-url';
import { getPageParams, getTotalPages } from '@/lib/pagination';
import BackButton from '@/app/components/BackButton';
import ShareButton from '@/app/components/ShareButton';
import PhotoGallery from '@/app/components/PhotoGallery';
import Pagination from '@/app/components/Pagination';
import AlbumCard from '@/app/components/AlbumCard';

export const revalidate = 3600;

// 这是个"虚拟路径"路由：域名/xxx 不对应任何一种固定的资源类型，
// 先当图集 slug 查，查不到再当标签名查，两种都查不到才是真的 404。
// 这样前台 URL 里就不用再看到 /albums、/tags 这种实现细节了。
//
// 注意：这里故意不写 generateStaticParams。
// 如果加上它，`next build` 会在构建镜像的阶段就去查数据库拿所有图集 slug，
// 但 docker build 阶段 Postgres 服务通常还没起来（build 和 up 是两个独立阶段），
// 构建环境也不一定连得上数据库，容易导致镜像构建失败。
// 不写这个函数，页面照样是 ISR：第一次访问时按需生成 + 缓存，之后跟静态页一样快。

const getAlbum = cache(async (slug: string) => {
  return prisma.album.findUnique({
    where: { slug, status: 'PUBLISHED' },
    include: {
      photos: { orderBy: { sortOrder: 'asc' } },
      category: { select: { name: true, slug: true, parent: { select: { name: true, slug: true } } } },
    },
  });
});

// 只查存在性，不用把整行数据都拉出来
const tagExists = cache(async (tag: string) => {
  const rows = await prisma.$queryRaw<{ exists: boolean }[]>`
    SELECT EXISTS (
      SELECT 1 FROM "Album", unnest("Album"."tags") AS t
      WHERE "Album"."status" = 'PUBLISHED' AND t = ${tag}
    ) AS exists
  `;
  return rows[0]?.exists ?? false;
});

// 上一个/下一个图集，按全局发布时间排序（跟首页默认顺序一致——首页是按发布时间从新到旧排的）。
// 所以"上一个"对应更新的那个，"下一个"对应更旧的那个，跟首页列表里的先后顺序保持一致。
// 没有区分当前分类，是因为详情页目前拿不到"访客是从哪个分类点进来的"这个上下文——
// 首页的链接是 /slug，没带 ?category=，要做到"分类内穿梭"得先把这个上下文传过来。
async function getAdjacentAlbums(current: { publishedAt: Date | null; createdAt: Date }) {
  const cursor = current.publishedAt ?? current.createdAt;

  const [prev, next] = await Promise.all([
    prisma.album.findFirst({
      where: { status: 'PUBLISHED', publishedAt: { gt: cursor } },
      orderBy: { publishedAt: 'asc' },
      select: { slug: true, title: true, coverKey: true, coverBlurDataURL: true },
    }),
    prisma.album.findFirst({
      where: { status: 'PUBLISHED', publishedAt: { lt: cursor } },
      orderBy: { publishedAt: 'desc' },
      select: { slug: true, title: true, coverKey: true, coverBlurDataURL: true },
    }),
  ]);

  return { prev, next };
}

type Params = Promise<{ slug: string }>;
type SearchParams = Promise<{ [key: string]: string | string[] | undefined }>;

export async function generateMetadata({
  params,
  searchParams,
}: {
  params: Params;
  searchParams: SearchParams;
}): Promise<Metadata> {
  const { slug } = await params;

  const album = await getAlbum(slug);
  if (album) {
    const settings = await getSiteSettings();
    const title = `${album.title} - ${settings.siteTitle}`;
    const description = album.description || settings.siteDescription;
    const cover = album.coverKey || album.photos[0]?.r2Key;
    const url = `${siteUrl()}/${album.slug}`;

    return {
      title,
      description,
      alternates: { canonical: url },
      openGraph: {
        title,
        description,
        url,
        type: 'article',
        // 供社交平台预览卡片、搜索引擎判断内容新鲜度用，不是给人看的展示位
        publishedTime: (album.publishedAt ?? album.createdAt).toISOString(),
        images: cover ? [{ url: publicUrl(cover) }] : undefined,
      },
      twitter: {
        card: cover ? 'summary_large_image' : 'summary',
        title,
        description,
        images: cover ? [publicUrl(cover)] : undefined,
      },
    };
  }

  const tag = decodeURIComponent(slug);
  if (await tagExists(tag)) {
    const { page } = getPageParams(await searchParams);
    const [settings, sample] = await Promise.all([
      getSiteSettings(),
      // 拿这个标签下最新的一张封面图当分享预览图，比用兜底的站点默认图更相关
      prisma.album.findFirst({
        where: { status: 'PUBLISHED', tags: { has: tag } },
        orderBy: { publishedAt: 'desc' },
        select: { coverKey: true },
      }),
    ]);

    const title = `标签：${tag}`;
    const description = `${settings.siteTitle}中标记为「${tag}」的图集`;
    const url = `${siteUrl()}/${encodeURIComponent(tag)}`;
    const image = sample?.coverKey ? publicUrl(sample.coverKey) : undefined;

    return {
      title,
      description,
      alternates: { canonical: url },
      // 翻页页面（第 2 页起）跟第 1 页内容重复度高，不值得单独索引
      ...(page > 1 ? { robots: { index: false, follow: true } } : {}),
      openGraph: {
        title,
        description,
        url,
        type: 'website',
        images: image ? [{ url: image }] : undefined,
      },
      twitter: {
        card: image ? 'summary_large_image' : 'summary',
        title,
        description,
        images: image ? [image] : undefined,
      },
    };
  }

  return {};
}

export default async function VirtualSlugPage({ params, searchParams }: { params: Params; searchParams: SearchParams }) {
  const { slug } = await params;

  const album = await getAlbum(slug);
  if (album) {
    return <AlbumView album={album} />;
  }

  const tag = decodeURIComponent(slug);
  if (await tagExists(tag)) {
    return <TagView tag={tag} searchParams={searchParams} />;
  }

  notFound();
}

// ---------------------------------------------------------------------------
// 图集详情视图
// ---------------------------------------------------------------------------

type AlbumWithRelations = NonNullable<Awaited<ReturnType<typeof getAlbum>>>;

async function AlbumView({ album }: { album: AlbumWithRelations }) {
  const { prev, next } = await getAdjacentAlbums(album);

  const albumUrl = `${siteUrl()}/${album.slug}`;
  // ImageGallery + 每张图片对应的 ImageObject：帮助 Google 图片搜索理解这是一个图集，
  // 以及每张图的尺寸、说明文字，从而更容易被图片搜索收录、展示更完整的信息。
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'ImageGallery',
    name: album.title,
    description: album.description || undefined,
    url: albumUrl,
    ...(album.photos.length > 0
      ? {
          image: album.photos.map((photo) => publicUrl(photo.r2Key)),
          associatedMedia: album.photos.map((photo) => ({
            '@type': 'ImageObject',
            contentUrl: publicUrl(photo.r2Key),
            width: photo.width,
            height: photo.height,
            name: photo.altText || album.title,
          })),
        }
      : {}),
  };

  return (
    <div id="top" className="mx-auto max-w-5xl px-4 py-8">
      <script
        type="application/ld+json"
        // JSON.stringify 出来的内容都来自数据库字段，理论上可能含 </script> 之类的字符，
        // 用 <\/script> 转义一下，避免被浏览器提前截断这段 script 标签
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, '\\u003c') }}
      />
      {album.category && (
        <div className="flex items-center gap-1 text-sm uppercase tracking-wide text-[var(--fg-50)]">
          {album.category.parent && (
            <>
              <a href={`/?category=${album.category.parent.slug}`} className="hover:text-[var(--text-color)]">
                {album.category.parent.name}
              </a>
              <span>/</span>
            </>
          )}
          <a href={`/?category=${album.category.slug}`} className="hover:text-[var(--text-color)]">
            {album.category.name}
          </a>
        </div>
      )}
      <h1 className="mt-1 text-2xl font-medium">{album.title}</h1>
      <time
        dateTime={(album.publishedAt ?? album.createdAt).toISOString()}
        className="mt-1 block text-sm text-[var(--fg-40)]"
      >
        {(album.publishedAt ?? album.createdAt).toLocaleDateString('zh-CN', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
        })}
      </time>
      {album.description && <p className="mt-2 text-[var(--fg-60)]">{album.description}</p>}
      {album.tags.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-2">
          {album.tags.map((tag) => (
            <Link
              key={tag}
              href={`/${encodeURIComponent(tag)}`}
              className="rounded-full bg-[var(--fg-10)] px-3 py-1 text-xs hover:bg-[var(--fg-20)]"
            >
              {tag}
            </Link>
          ))}
        </div>
      )}

      <div className="mt-4 -ml-3">
        <ShareButton
          title={album.title}
          coverUrl={
            album.coverKey || album.photos[0]?.r2Key
              ? publicUrl(album.coverKey || album.photos[0]!.r2Key)
              : undefined
          }
        />
      </div>

      <PhotoGallery
        photos={album.photos.map((photo) => ({
          id: photo.id,
          url: publicUrl(photo.r2Key),
          width: photo.width,
          height: photo.height,
          alt: photo.altText || album.title,
          blurDataURL: photo.blurDataURL || undefined,
        }))}
      />

      <div className="mt-10 -mx-3 flex items-center justify-between gap-1 text-sm">
        <Link
          href="/"
          className="flex min-h-11 items-center gap-1 rounded px-3 text-[var(--fg-50)] hover:bg-[var(--fg-5)] hover:text-[var(--text-color)]"
        >
          <span aria-hidden>⌂</span> 首页
        </Link>

        <a
          href="#top"
          className="flex min-h-11 items-center gap-1 rounded px-3 text-[var(--fg-50)] hover:bg-[var(--fg-5)] hover:text-[var(--text-color)]"
        >
          <span aria-hidden>↑</span> 返回顶部
        </a>

        <BackButton />
      </div>

      <nav className="mt-4 grid grid-cols-2 gap-3 border-t border-[var(--fg-10)] pt-6">
        {prev ? (
          <Link href={`/${prev.slug}`} className="group flex min-w-0 items-center gap-3 overflow-hidden">
            {prev.coverKey && (
              <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded bg-[var(--fg-5)]">
                <Image
                  src={publicUrl(prev.coverKey)}
                  alt=""
                  fill
                  sizes="56px"
                  className="object-cover"
                  {...(prev.coverBlurDataURL
                    ? { placeholder: 'blur' as const, blurDataURL: prev.coverBlurDataURL }
                    : {})}
                />
              </div>
            )}
            <div className="min-w-0">
              <p className="text-xs text-[var(--fg-50)]">上一个</p>
              <p className="truncate text-sm text-[var(--fg-80)] group-hover:text-[var(--text-color)]">
                {prev.title}
              </p>
            </div>
          </Link>
        ) : (
          <div />
        )}

        {next ? (
          <Link
            href={`/${next.slug}`}
            className="group flex min-w-0 items-center justify-end gap-3 overflow-hidden text-right"
          >
            <div className="min-w-0">
              <p className="text-xs text-[var(--fg-50)]">下一个</p>
              <p className="truncate text-sm text-[var(--fg-80)] group-hover:text-[var(--text-color)]">
                {next.title}
              </p>
            </div>
            {next.coverKey && (
              <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded bg-[var(--fg-5)]">
                <Image
                  src={publicUrl(next.coverKey)}
                  alt=""
                  fill
                  sizes="56px"
                  className="object-cover"
                  {...(next.coverBlurDataURL
                    ? { placeholder: 'blur' as const, blurDataURL: next.coverBlurDataURL }
                    : {})}
                />
              </div>
            )}
          </Link>
        ) : (
          <div />
        )}
      </nav>

      {/* 浏览量埋点：客户端上报，不影响静态页缓存 */}
      <ViewTracker slug={album.slug} />
    </div>
  );
}

function ViewTracker({ slug }: { slug: string }) {
  return (
    <script
      dangerouslySetInnerHTML={{
        __html: `fetch('/api/albums/${slug}/view', { method: 'POST' }).catch(() => {});`,
      }}
    />
  );
}

// ---------------------------------------------------------------------------
// 标签列表视图
// ---------------------------------------------------------------------------

async function TagView({ tag, searchParams }: { tag: string; searchParams: SearchParams }) {
  const sp = await searchParams;
  const { page, skip, take } = getPageParams(sp);

  const where = { status: 'PUBLISHED' as const, tags: { has: tag } };

  const [albums, totalCount] = await Promise.all([
    prisma.album.findMany({
      where,
      orderBy: { publishedAt: 'desc' },
      skip,
      take,
      select: { title: true, slug: true, coverKey: true, coverBlurDataURL: true, tags: true },
    }),
    prisma.album.count({ where }),
  ]);

  const totalPages = getTotalPages(totalCount);

  return (
    <div>
      <div className="flex items-center justify-between gap-2 px-4 py-4">
        <h1 className="text-lg text-[var(--fg-80)]">
          标签：<span className="text-[var(--text-color)]">{tag}</span>
        </h1>
        <Link href="/tags" className="text-sm text-[var(--fg-50)] hover:text-[var(--text-color)]">
          全部标签
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-x-1 gap-y-3 p-1 sm:grid-cols-3 md:grid-cols-4">
        {albums.map((album, index) => (
          <AlbumCard key={album.slug} album={album} priority={index === 0} />
        ))}
        {albums.length === 0 && (
          <p className="col-span-full p-8 text-center text-[var(--fg-50)]">这个标签下暂时没有图集</p>
        )}
      </div>

      <Pagination currentPage={page} totalPages={totalPages} basePath={`/${encodeURIComponent(tag)}`} />
    </div>
  );
}
