import { ImageResponse } from 'next/og';
import { getSiteSettings } from '@/lib/settings';
import { getContrastTextColor } from '@/lib/color';
import { getLogoDataUri } from '@/lib/site-asset';

// 跟 icon.tsx / apple-icon.tsx 一样：要查数据库拿站点设置，Prisma 不支持 Edge runtime
export const runtime = 'nodejs';
export const revalidate = 3600;

export const alt = '站点分享预览';
export const size = { width: 1200, height: 630 };
export const contentType = 'image/png';

// 这是"兜底"的分享预览图：只有当某个路由自己没有通过 generateMetadata 提供
// openGraph.images 时，Next 才会用这张图（比如首页、关于页、标签列表页、搜索页）。
// 图集详情页已经在 generateMetadata 里指定了封面图作为 openGraph.images，
// 优先级更高，不会用到这张兜底图。
export default async function OpengraphImage() {
  const [settings, logoDataUri] = await Promise.all([getSiteSettings(), getLogoDataUri()]);
  const textColor = getContrastTextColor(settings.accentColor);

  const badge = logoDataUri ? (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={logoDataUri}
      width={140}
      height={140}
      style={{ objectFit: 'contain', marginBottom: 40 }}
    />
  ) : (
    <div
      style={{
        width: 140,
        height: 140,
        borderRadius: 28,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: settings.accentColor,
        color: textColor,
        fontSize: 64,
        fontWeight: 600,
        marginBottom: 40,
      }}
    >
      {(settings.siteTitle?.trim()?.[0] || '图').toUpperCase()}
    </div>
  );

  const content = (
    <div
      style={{
        width: '100%',
        height: '100%',
        display: 'flex',
        flexDirection: 'column' as const,
        alignItems: 'center',
        justifyContent: 'center',
        background: settings.backgroundColor,
        color: settings.textColor,
        padding: 80,
      }}
    >
      {badge}
      <div style={{ display: 'flex', fontSize: 68, fontWeight: 600, textAlign: 'center' as const }}>
        {settings.siteTitle}
      </div>
      {settings.siteDescription && (
        <div
          style={{
            display: 'flex',
            marginTop: 24,
            fontSize: 32,
            color: settings.accentColor,
            textAlign: 'center' as const,
            maxWidth: 880,
          }}
        >
          {settings.siteDescription}
        </div>
      )}
    </div>
  );

  try {
    return new ImageResponse(content, { ...size });
  } catch {
    // satori 渲染 logo 失败时（比如图片格式它不认），退回不带 logo 的纯文字版，
    // 避免分享预览图直接 500
    return new ImageResponse(
      (
        <div
          style={{
            width: '100%',
            height: '100%',
            display: 'flex',
            flexDirection: 'column' as const,
            alignItems: 'center',
            justifyContent: 'center',
            background: settings.backgroundColor,
            color: settings.textColor,
            padding: 80,
          }}
        >
          <div style={{ display: 'flex', fontSize: 68, fontWeight: 600, textAlign: 'center' as const }}>
            {settings.siteTitle}
          </div>
        </div>
      ),
      { ...size },
    );
  }
}
