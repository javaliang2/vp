'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { uploadPhoto } from '../photo-upload';

type Category = { id: string; name: string; slug: string; parentId: string | null };

export default function NewAlbumPage() {
  const router = useRouter();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [tags, setTags] = useState('');
  const [categories, setCategories] = useState<Category[]>([]);
  const [parentCategoryId, setParentCategoryId] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [coverIndex, setCoverIndex] = useState(0);
  const [progress, setProgress] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetch('/api/admin/categories')
      .then((r) => r.json())
      .then(setCategories)
      .catch(() => {});
  }, []);

  function handleFilesChange(fileList: FileList | null) {
    const list = Array.from(fileList || []);
    setFiles(list);
    setCoverIndex(0);
    previews.forEach((url) => URL.revokeObjectURL(url));
    setPreviews(list.map((f) => URL.createObjectURL(f)));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (files.length === 0) return;
    setSubmitting(true);

    const photos = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      setProgress(`正在上传第 ${i + 1} / ${files.length} 张…`);

      const { r2Key, thumbKey, width, height, blurDataURL } = await uploadPhoto(file, title);
      photos.push({ r2Key, thumbKey, width, height, altText: title, blurDataURL });
    }

    setProgress('正在保存图集…');
    const res = await fetch('/api/admin/albums', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title,
        description,
        tags: tags.split(',').map((t) => t.trim()).filter(Boolean),
        categoryId: categoryId || parentCategoryId || null,
        coverIndex,
        photos,
      }),
    });

    setSubmitting(false);
    if (res.ok) {
      router.push('/admin');
      router.refresh();
    } else {
      const data = await res.json();
      setProgress('');
      alert(data.error || '保存失败');
    }
  }

  return (
    <div className="mx-auto max-w-xl px-4 py-8">
      <h1 className="mb-6 text-xl">新建图集</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          placeholder="标题"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        />
        <textarea
          placeholder="描述（可选）"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          rows={3}
        />
        <input
          placeholder="标签，用逗号分隔"
          value={tags}
          onChange={(e) => setTags(e.target.value)}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
        />
        <div className="flex flex-col gap-2 sm:flex-row">
          <select
            value={parentCategoryId}
            onChange={(e) => {
              setParentCategoryId(e.target.value);
              setCategoryId(''); // 换大类后清空已选的子分类
            }}
            className="flex-1 rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          >
            <option value="" className="bg-black">选择大类</option>
            {categories
              .filter((c) => !c.parentId)
              .map((c) => (
                <option key={c.id} value={c.id} className="bg-black">
                  {c.name}
                </option>
              ))}
          </select>
          <select
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value)}
            disabled={!parentCategoryId}
            className="flex-1 rounded border border-[var(--fg-20)] bg-transparent px-3 py-2 disabled:opacity-40"
          >
            <option value="" className="bg-black">
              {parentCategoryId ? '不选子分类（直接挂在大类下）' : '先选大类'}
            </option>
            {categories
              .filter((c) => c.parentId === parentCategoryId)
              .map((c) => (
                <option key={c.id} value={c.id} className="bg-black">
                  {c.name}
                </option>
              ))}
          </select>
        </div>
        <input
          type="file"
          accept="image/*"
          multiple
          onChange={(e) => handleFilesChange(e.target.files)}
          className="w-full text-sm"
        />

        {previews.length > 0 && (
          <div>
            <p className="mb-2 text-xs text-[var(--fg-50)]">点击图片设为封面（当前：第 {coverIndex + 1} 张）</p>
            <div className="grid grid-cols-4 gap-2">
              {previews.map((src, i) => (
                <button
                  type="button"
                  key={src}
                  onClick={() => setCoverIndex(i)}
                  style={i === coverIndex ? { boxShadow: '0 0 0 2px var(--accent-color)' } : undefined}
                  className={`relative aspect-square overflow-hidden rounded ${
                    i === coverIndex ? '' : 'opacity-70'
                  }`}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={src} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          </div>
        )}

        <button
          type="submit"
          disabled={submitting || !title || files.length === 0}
          style={{ backgroundColor: 'var(--accent-color)' }}
          className="w-full rounded py-2 text-[var(--accent-contrast)] disabled:opacity-50"
        >
          {submitting ? progress || '提交中…' : `发布（${files.length} 张图片）`}
        </button>
      </form>
    </div>
  );
}
