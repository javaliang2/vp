'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

export default function DeleteNavLinkButton({ id }: { id: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function handleDelete() {
    if (!confirm('确定删除这个菜单项吗？')) return;
    setLoading(true);
    await fetch(`/api/admin/navlinks/${id}`, { method: 'DELETE' });
    setLoading(false);
    router.refresh();
  }

  return (
    <button
      onClick={handleDelete}
      disabled={loading}
      className="text-red-400 hover:text-red-300 disabled:opacity-50"
    >
      {loading ? '删除中…' : '删除'}
    </button>
  );
}
