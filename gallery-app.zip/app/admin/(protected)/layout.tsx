import Link from 'next/link';
import LogoutButton from './LogoutButton';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div>
      <nav className="border-b border-[var(--fg-10)] bg-[var(--fg-5)]">
        <div className="mx-auto flex max-w-4xl flex-wrap items-center gap-x-1 gap-y-2 px-4 py-3 text-sm">
          <Link href="/admin" className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]">
            图集管理
          </Link>
          <Link
            href="/admin/categories"
            className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
          >
            分类管理
          </Link>
          <Link
            href="/admin/menu"
            className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
          >
            导航菜单
          </Link>
          <Link
            href="/admin/settings"
            className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
          >
            外观设置
          </Link>

          <div className="ml-auto flex items-center gap-1">
            <a
              href="/"
              target="_blank"
              rel="noopener noreferrer"
              className="rounded px-3 py-1.5 text-[var(--fg-70)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
            >
              查看前台 ↗
            </a>
            <LogoutButton />
          </div>
        </div>
      </nav>
      {children}
    </div>
  );
}
