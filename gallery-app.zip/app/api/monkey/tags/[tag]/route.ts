import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { broadcastCacheInvalidation } from '@/lib/cache-broadcast';
import { findConflictingTag } from '@/lib/slug';

// 重命名 / 合并标签。如果 newName 已经是另一个标签的名字，效果就是合并：
// 两个标签下的图集会变成同一个标签，重复的标签名靠 Set 去重，不会出现同一个图集挂两个一样的标签。
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ tag: string }> }) {
  const { tag } = await params;
  const oldTag = decodeURIComponent(tag);
  const { newName } = await req.json();
  const trimmed = typeof newName === 'string' ? newName.trim() : '';

  if (!trimmed) {
    return NextResponse.json({ error: '请输入新的标签名' }, { status: 400 });
  }
  if (trimmed === oldTag) {
    return NextResponse.json({ ok: true }); // 没变化，直接算成功
  }

  const conflict = await findConflictingTag([trimmed]);
  if (conflict) {
    return NextResponse.json(
      { error: `标签名"${conflict}"和站点固定路径或已有图集地址重名，换一个名字` },
      { status: 400 },
    );
  }

  const albums = await prisma.album.findMany({
    where: { tags: { has: oldTag } },
    select: { id: true, tags: true },
  });

  await prisma.$transaction(
    albums.map((album) =>
      prisma.album.update({
        where: { id: album.id },
        data: {
          tags: Array.from(new Set(album.tags.map((t) => (t === oldTag ? trimmed : t)))),
        },
      }),
    ),
  );

  revalidatePath('/tags');
  revalidatePath(`/${encodeURIComponent(oldTag)}`);
  revalidatePath(`/${encodeURIComponent(trimmed)}`);
  await broadcastCacheInvalidation([
    { path: '/tags' },
    { path: `/${encodeURIComponent(oldTag)}` },
    { path: `/${encodeURIComponent(trimmed)}` },
  ]);

  return NextResponse.json({ ok: true, affected: albums.length });
}

// 删除标签：只是把这个标签从所有图集的 tags 数组里摘掉，图集本身不受影响。
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ tag: string }> }) {
  const { tag } = await params;
  const target = decodeURIComponent(tag);

  const albums = await prisma.album.findMany({
    where: { tags: { has: target } },
    select: { id: true, tags: true },
  });

  await prisma.$transaction(
    albums.map((album) =>
      prisma.album.update({
        where: { id: album.id },
        data: { tags: album.tags.filter((t) => t !== target) },
      }),
    ),
  );

  revalidatePath('/tags');
  revalidatePath(`/${encodeURIComponent(target)}`);
  await broadcastCacheInvalidation([{ path: '/tags' }, { path: `/${encodeURIComponent(target)}` }]);

  return NextResponse.json({ ok: true, affected: albums.length });
}
