import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { invalidateNavLinksCache } from '@/lib/navlinks';
import { broadcastCacheInvalidation } from '@/lib/cache-broadcast';

// 导航菜单是渲染给所有前台访客看的，不是后台专属页面——
// 这里没做协议校验的话，存进去一个 javascript:/data: 链接，每个访客点了都会在浏览器里执行。
// 只允许站内路径，以及 http(s)/mailto/tel 这几种正常会用到的协议。
function isAllowedUrl(url: string): boolean {
  if (url.startsWith('/')) return true;
  return /^(https?:|mailto:|tel:)/i.test(url);
}

export async function GET() {
  const links = await prisma.navLink.findMany({ orderBy: { sortOrder: 'asc' } });
  return NextResponse.json(links);
}

export async function POST(req: NextRequest) {
  const { label, url, categoryId, newTab, sortOrder } = await req.json();
  if (!label) {
    return NextResponse.json({ error: '请填写菜单文字' }, { status: 400 });
  }
  if (!categoryId && !url) {
    return NextResponse.json({ error: '关联分类和自定义链接至少要选一个' }, { status: 400 });
  }
  if (!categoryId && url && !isAllowedUrl(url)) {
    return NextResponse.json(
      { error: '链接格式不支持，只能是站内路径（以 / 开头）或 http(s)/mailto/tel 链接' },
      { status: 400 },
    );
  }

  const link = await prisma.navLink.create({
    data: {
      label,
      url: categoryId ? null : url, // 关联了分类的话，实际链接由 categoryId 现算，url 就不存了
      categoryId: categoryId || null,
      newTab: Boolean(newTab),
      sortOrder: Number.isFinite(sortOrder) ? sortOrder : 0,
    },
  });

  // 导航菜单是根 layout 的一部分，跟站点设置一样要让所有页面的布局缓存失效
  await invalidateNavLinksCache();
  revalidatePath('/', 'layout');
  await broadcastCacheInvalidation([{ path: '/', type: 'layout' }]);
  return NextResponse.json(link, { status: 201 });
}
