import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { invalidateNavLinksCache } from '@/lib/navlinks';
import { broadcastCacheInvalidation } from '@/lib/cache-broadcast';

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  await prisma.navLink.delete({ where: { id } });
  await invalidateNavLinksCache();
  revalidatePath('/', 'layout');
  await broadcastCacheInvalidation([{ path: '/', type: 'layout' }]);
  return NextResponse.json({ ok: true });
}
