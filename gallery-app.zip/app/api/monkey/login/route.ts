import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/db';
import { createSession } from '@/lib/auth';
import { isRateLimited } from '@/lib/rate-limit';
import { getClientIp } from '@/lib/client-ip';

const MAX_ATTEMPTS = 5;
const LOCK_MINUTES = 15;

// 账号锁定（下面的 failedAttempts/lockedUntil）防的是"盯着一个邮箱猛试密码"；
// 这里的 IP 限流防的是另一种情况——换着不同邮箱高频撞库，账号锁定单独看每个邮箱都还没到阈值，
// 但同一个 IP 短时间内打了很多次登录请求。两者互补，不是重复。
const IP_RATE_LIMIT_WINDOW_MS = 60 * 1000;
const IP_RATE_LIMIT_MAX = 10; // 每个 IP 每分钟最多 10 次登录请求（不管邮箱密码对不对，先按请求数算）

export async function POST(req: NextRequest) {
  const ip = getClientIp(req);
  if (await isRateLimited('loginratelimit', ip, { windowMs: IP_RATE_LIMIT_WINDOW_MS, max: IP_RATE_LIMIT_MAX })) {
    return NextResponse.json({ error: '登录请求过于频繁，请稍后再试' }, { status: 429 });
  }

  const { email, password } = await req.json();

  if (!email || !password) {
    return NextResponse.json({ error: '请输入邮箱和密码' }, { status: 400 });
  }

  const user = await prisma.adminUser.findUnique({ where: { email } });

  // 邮箱不存在时也返回统一的错误文案，不透露账号是否存在
  if (!user) {
    return NextResponse.json({ error: '邮箱或密码错误' }, { status: 401 });
  }

  // 账号被锁定期间，直接拒绝，不再尝试校验密码
  if (user.lockedUntil && user.lockedUntil > new Date()) {
    const remainingMin = Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60000);
    return NextResponse.json(
      { error: `登录失败次数过多，账号已锁定，请 ${remainingMin} 分钟后再试` },
      { status: 429 }
    );
  }

  const valid = await bcrypt.compare(password, user.passwordHash);

  if (!valid) {
    const failedAttempts = user.failedAttempts + 1;
    const shouldLock = failedAttempts >= MAX_ATTEMPTS;

    await prisma.adminUser.update({
      where: { id: user.id },
      data: {
        failedAttempts: shouldLock ? 0 : failedAttempts,
        lockedUntil: shouldLock ? new Date(Date.now() + LOCK_MINUTES * 60_000) : null,
      },
    });

    if (shouldLock) {
      return NextResponse.json(
        { error: `连续输错 ${MAX_ATTEMPTS} 次，账号已锁定 ${LOCK_MINUTES} 分钟` },
        { status: 429 }
      );
    }

    return NextResponse.json(
      { error: `邮箱或密码错误（还可以尝试 ${MAX_ATTEMPTS - failedAttempts} 次）` },
      { status: 401 }
    );
  }

  // 登录成功，清空失败记录
  if (user.failedAttempts > 0 || user.lockedUntil) {
    await prisma.adminUser.update({
      where: { id: user.id },
      data: { failedAttempts: 0, lockedUntil: null },
    });
  }

  await createSession(user.id);
  return NextResponse.json({ ok: true });
}
