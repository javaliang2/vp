import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { broadcastCacheInvalidation } from '@/lib/cache-broadcast';

// POST: 给已有图集追加图片
// body: { photos: [{ r2Key, thumbKey, width, height, altText }] }
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { photos } = await req.json();

  if (!Array.isArray(photos) || photos.length === 0) {
    return NextResponse.json({ error: '没有要添加的图片' }, { status: 400 });
  }

  const album = await prisma.album.findUnique({ where: { id }, select: { slug: true, coverKey: true } });
  if (!album) {
    return NextResponse.json({ error: '图集不存在' }, { status: 404 });
  }

  // 接在现有图片后面，用 max(sortOrder) 而不是数量，避免中间删过图之后编号对不上
  const agg = await prisma.photo.aggregate({ where: { albumId: id }, _max: { sortOrder: true } });
  const startOrder = (agg._max.sortOrder ?? -1) + 1;

  await prisma.photo.createMany({
    data: photos.map((p: any, i: number) => ({
      albumId: id,
      r2Key: p.r2Key,
      thumbKey: p.thumbKey,
      width: p.width,
      height: p.height,
      altText: p.altText || '',
      blurDataURL: p.blurDataURL || null,
      sortOrder: startOrder + i,
    })),
  });

  // 图集之前一张图都没有（封面是空的）的话，顺便把新加的第一张设成封面
  if (!album.coverKey) {
    await prisma.album.update({
      where: { id },
      data: { coverKey: photos[0].thumbKey, coverBlurDataURL: photos[0].blurDataURL || null },
    });
  }

  revalidatePath('/');
  revalidatePath(`/albums/${album.slug}`);
  await broadcastCacheInvalidation([{ path: '/' }, { path: `/albums/${album.slug}` }]);

  const all = await prisma.photo.findMany({ where: { albumId: id }, orderBy: { sortOrder: 'asc' } });
  return NextResponse.json(all, { status: 201 });
}
