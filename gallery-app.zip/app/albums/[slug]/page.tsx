import { permanentRedirect } from 'next/navigation';

// 图集详情页已经搬到扁平路径 /slug（见 app/[slug]/page.tsx）。
// 这里只保留一个 308 永久重定向，兼容外部已经收藏/分享出去的旧链接，
// 别删这个文件，删了老链接直接 404。
export default async function LegacyAlbumRedirect({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  permanentRedirect(`/${slug}`);
}
