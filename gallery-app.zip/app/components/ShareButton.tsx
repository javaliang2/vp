'use client';

import { useEffect, useState } from 'react';

export default function ShareButton({ title, coverUrl }: { title: string; coverUrl?: string }) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [url, setUrl] = useState('');
  const [canNativeShare, setCanNativeShare] = useState(false);

  // window / navigator 只在客户端存在，放到 effect 里读，避免服务端渲染和客户端 hydrate 对不上
  useEffect(() => {
    setCanNativeShare(typeof navigator !== 'undefined' && typeof navigator.share === 'function');
  }, []);

  useEffect(() => {
    if (open) setUrl(window.location.href);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    function handleEscape(e: KeyboardEvent) {
      if (e.key === 'Escape') setOpen(false);
    }
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [open]);

  async function handleNativeShare() {
    try {
      await navigator.share({ title, url });
      setOpen(false);
    } catch {
      // 用户在系统分享面板里点了取消，navigator.share 也会 reject，
      // 保留预览卡片让用户可以选别的方式，不用做什么
    }
  }

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // clipboard 也失败的话（比如非 HTTPS），没有更好的兜底了，静默失败
    }
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="inline-flex min-h-9 items-center gap-1 rounded px-3 text-sm text-[var(--fg-50)] hover:bg-[var(--fg-5)] hover:text-[var(--text-color)]"
      >
        <span aria-hidden>⇪</span> 分享
      </button>

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-4 sm:items-center"
          onClick={() => setOpen(false)}
        >
          <div
            className="w-full max-w-sm overflow-hidden rounded-xl border border-[var(--fg-10)] bg-[var(--bg-color)] shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            {coverUrl && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={coverUrl} alt="" className="h-40 w-full object-cover" />
            )}

            <div className="p-4">
              <p className="text-xs uppercase tracking-wide text-[var(--fg-40)]">分享预览</p>
              <p className="mt-1 truncate text-sm font-medium text-[var(--text-color)]">{title}</p>
              <p className="mt-1 truncate text-xs text-[var(--fg-40)]">{url}</p>

              <div className="mt-4 flex gap-2">
                {canNativeShare && (
                  <button
                    type="button"
                    onClick={handleNativeShare}
                    className="flex-1 rounded-md px-3 py-2 text-sm"
                    style={{ backgroundColor: 'var(--accent-color)', color: 'var(--accent-contrast)' }}
                  >
                    系统分享
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleCopy}
                  className="flex-1 rounded-md border border-[var(--fg-20)] px-3 py-2 text-sm text-[var(--text-color)] hover:bg-[var(--fg-5)]"
                >
                  {copied ? '已复制' : '复制链接'}
                </button>
              </div>

              <button
                type="button"
                onClick={() => setOpen(false)}
                className="mt-3 w-full rounded-md py-1.5 text-center text-xs text-[var(--fg-40)] hover:text-[var(--text-color)]"
              >
                取消
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
