'use client';

// 这个按钮就靠它自己触发 history.back()，没法用纯 <a> 实现，所以单独拆成一个小的客户端组件，
// 其余"首页"/"返回顶部"都还是普通链接，不用额外的 JS。
export default function BackButton() {
  return (
    <button
      type="button"
      onClick={() => window.history.back()}
      className="flex min-h-11 items-center gap-1 rounded px-3 text-sm text-[var(--fg-50)] hover:bg-[var(--fg-5)] hover:text-[var(--text-color)]"
    >
      后退 <span aria-hidden>→</span>
    </button>
  );
}
