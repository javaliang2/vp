'use client';

import { useEffect, useState } from 'react';

// 跟 layout.tsx <head> 里那段防闪屏脚本共用同一个 key，两边必须保持一致。
const STORAGE_KEY = 'gallery-theme'; // 'dark' | 'light'

export default function ThemeToggle() {
  // 初始值先假设 false（日间），挂载后立刻用 <html> 上的实际 class 校正一次——
  // 这个 class 是防闪屏脚本在 hydration 之前就加好的，所以这里只是把 React state 对齐上去，不会闪。
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    setIsDark(document.documentElement.classList.contains('dark-mode'));
  }, []);

  function toggle() {
    const next = !isDark;
    setIsDark(next);
    document.documentElement.classList.toggle('dark-mode', next);
    try {
      localStorage.setItem(STORAGE_KEY, next ? 'dark' : 'light');
    } catch {
      // 隐私模式下 localStorage 可能不可用，切换本身仍然生效，只是刷新后记不住，不影响使用
    }
  }

  return (
    <button
      type="button"
      onClick={toggle}
      aria-label={isDark ? '切换到日间模式' : '切换到夜间模式'}
      title={isDark ? '日间模式' : '夜间模式'}
      className="flex h-11 w-11 items-center justify-center rounded-md text-[var(--fg-70)] transition hover:bg-[var(--fg-5)] hover:text-[var(--text-color)]"
    >
      {isDark ? (
        // 当前是夜间：显示太阳，点一下切回日间
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
          <circle cx="9" cy="9" r="3.2" stroke="currentColor" strokeWidth="1.6" />
          <line x1="9" y1="1.5" x2="9" y2="3.3" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <line x1="9" y1="14.7" x2="9" y2="16.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <line x1="1.5" y1="9" x2="3.3" y2="9" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <line x1="14.7" y1="9" x2="16.5" y2="9" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <line x1="3.7" y1="3.7" x2="5" y2="5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <line x1="13" y1="13" x2="14.3" y2="14.3" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <line x1="3.7" y1="14.3" x2="5" y2="13" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          <line x1="13" y1="5" x2="14.3" y2="3.7" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
      ) : (
        // 当前是日间：显示月亮，点一下切到夜间
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
          <path
            d="M15.75 9.59A6.75 6.75 0 1 1 8.41 2.25 5.25 5.25 0 0 0 15.75 9.59z"
            fill="currentColor"
          />
        </svg>
      )}
    </button>
  );
}
