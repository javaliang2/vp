import Link from 'next/link';
import Image from 'next/image';
import { publicUrl } from '@/lib/r2';

type AlbumCardData = {
  title: string;
  slug: string;
  coverKey: string | null;
  coverBlurDataURL: string | null;
  tags: string[];
};

// 标签最多显示 3 个，太多的话卡片高度参差不齐、网格看着会很乱；
// 多出来的用一个 "+N" 提示一下就好，不用挨个列出来
const MAX_VISIBLE_TAGS = 3;

export default function AlbumCard({ album, priority }: { album: AlbumCardData; priority: boolean }) {
  const visibleTags = album.tags.slice(0, MAX_VISIBLE_TAGS);
  const remaining = album.tags.length - visibleTags.length;

  return (
    <div className="group">
      <Link href={`/${album.slug}`} className="block">
        <div className="relative aspect-square overflow-hidden bg-[var(--fg-5)]">
          {album.coverKey && (
            <Image
              src={publicUrl(album.coverKey)}
              alt={album.title}
              fill
              sizes="(max-width: 768px) 50vw, 25vw"
              className="object-cover transition duration-500 group-hover:scale-105"
              priority={priority}
              loading={priority ? undefined : 'lazy'}
              {...(album.coverBlurDataURL
                ? { placeholder: 'blur' as const, blurDataURL: album.coverBlurDataURL }
                : {})}
            />
          )}
        </div>
        <p className="mt-1.5 truncate px-0.5 text-base text-[var(--fg-80)] group-hover:text-[var(--text-color)]">
          {album.title}
        </p>
      </Link>

      {/* 标签是单独的链接（跳到 /tags/[tag]），不能嵌套在上面 <Link> 的 <a> 里面，
          所以放在外层 div 下面当兄弟节点，视觉上依然紧贴在标题下方 */}
      {visibleTags.length > 0 && (
        <div className="mt-1 flex flex-wrap items-center gap-x-1.5 gap-y-0.5 px-0.5">
          {visibleTags.map((tag) => (
            <Link
              key={tag}
              href={`/${encodeURIComponent(tag)}`}
              className="truncate text-xs text-[var(--fg-40)] hover:text-[var(--fg-70)]"
            >
              #{tag}
            </Link>
          ))}
          {remaining > 0 && <span className="text-xs text-[var(--fg-30)]">+{remaining}</span>}
        </div>
      )}
    </div>
  );
}
