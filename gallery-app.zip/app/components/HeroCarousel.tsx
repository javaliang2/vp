'use client';

import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { publicUrl } from '@/lib/r2';

export type CarouselAlbum = {
  title: string;
  slug: string;
  coverKey: string | null;
  coverBlurDataURL: string | null;
};

const AUTOPLAY_INTERVAL_MS = 3000;

type Tab = 'popular' | 'latest';

export default function HeroCarousel({ popular, latest }: { popular: CarouselAlbum[]; latest: CarouselAlbum[] }) {
  // 两个 tab 都没数据就整个不渲染，不占地方
  const hasPopular = popular.length > 0;
  const hasLatest = latest.length > 0;

  // 默认优先显示热门，热门没数据的话（比如刚上线还没积累浏览量）直接显示最新
  const [tab, setTab] = useState<Tab>(hasPopular ? 'popular' : 'latest');
  const [index, setIndex] = useState(0);
  const isHovering = useRef(false);

  const items = tab === 'popular' ? popular : latest;

  // 切 tab 时把下标归零，避免切过去发现下标越界或者停在一张不相关的图上
  function switchTab(next: Tab) {
    setTab(next);
    setIndex(0);
  }

  // 自动播放：用 ref 记 hover 状态，而不是把 isHovering 放进 useEffect 依赖里，
  // 这样鼠标进出不会一直销毁重建定时器，只有切 tab / 换图集数量时才重新起一个
  useEffect(() => {
    if (items.length <= 1) return;
    const timer = setInterval(() => {
      if (isHovering.current) return;
      setIndex((i) => (i + 1) % items.length);
    }, AUTOPLAY_INTERVAL_MS);
    return () => clearInterval(timer);
  }, [tab, items.length]);

  if (!hasPopular && !hasLatest) return null;

  const current = items[index];

  return (
    <div
      className="relative mx-1 mt-3 overflow-hidden rounded-2xl bg-[var(--fg-5)]"
      onMouseEnter={() => (isHovering.current = true)}
      onMouseLeave={() => (isHovering.current = false)}
    >
      {/* Tab 切换：两个都有数据才显示切换按钮，否则只有一种数据源，没必要给选择 */}
      {hasPopular && hasLatest && (
        <div className="absolute left-3 top-3 z-10 flex gap-1 rounded-full bg-black/40 p-1 backdrop-blur-sm">
          {(['popular', 'latest'] as const).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => switchTab(t)}
              className={`min-h-8 rounded-full px-3 text-sm transition ${
                tab === t ? 'bg-white text-black' : 'text-white/80 hover:text-white'
              }`}
            >
              {t === 'popular' ? '热门' : '最新'}
            </button>
          ))}
        </div>
      )}

      <Link href={`/albums/${current.slug}`} className="group block">
        <div className="relative aspect-[16/9] w-full sm:aspect-[21/9]">
          {current.coverKey && (
            <Image
              src={publicUrl(current.coverKey)}
              alt={current.title}
              fill
              sizes="100vw"
              priority
              className="object-cover transition duration-500 group-hover:scale-105"
              {...(current.coverBlurDataURL
                ? { placeholder: 'blur' as const, blurDataURL: current.coverBlurDataURL }
                : {})}
            />
          )}
          {/* 底部渐变遮罩，保证标题在任意封面图上都看得清 */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/0 to-black/0" />
          <p className="absolute bottom-4 left-4 right-16 truncate text-lg text-white sm:text-xl">{current.title}</p>
        </div>
      </Link>

      {items.length > 1 && (
        <>
          <button
            type="button"
            onClick={() => setIndex((i) => (i - 1 + items.length) % items.length)}
            aria-label="上一张"
            className="absolute left-2 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-black/40 text-white transition hover:bg-black/60"
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
              <path d="M10 3L5 8l5 5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <button
            type="button"
            onClick={() => setIndex((i) => (i + 1) % items.length)}
            aria-label="下一张"
            className="absolute right-2 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-black/40 text-white transition hover:bg-black/60"
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
              <path d="M6 3l5 5-5 5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>

          <div className="absolute bottom-4 right-4 flex gap-1.5">
            {items.map((item, i) => (
              <button
                key={item.slug}
                type="button"
                onClick={() => setIndex(i)}
                aria-label={`跳到第 ${i + 1} 张`}
                className={`h-1.5 rounded-full transition-all ${
                  i === index ? 'w-5 bg-white' : 'w-1.5 bg-white/50 hover:bg-white/80'
                }`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
