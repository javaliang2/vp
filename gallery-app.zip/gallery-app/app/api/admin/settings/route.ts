import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { revalidatePath } from 'next/cache';

export async function GET() {
  const settings = await prisma.siteSetting.findUnique({ where: { id: 1 } });
  return NextResponse.json(settings);
}

export async function PATCH(req: NextRequest) {
  const body = await req.json();
  const { siteTitle, siteDescription, logoKey, backgroundColor, textColor, accentColor, icpNumber, contactInfo, aboutContent } =
    body;

  const settings = await prisma.siteSetting.upsert({
    where: { id: 1 },
    update: { siteTitle, siteDescription, logoKey, backgroundColor, textColor, accentColor, icpNumber, contactInfo, aboutContent },
    create: { id: 1, siteTitle, siteDescription, logoKey, backgroundColor, textColor, accentColor, icpNumber, contactInfo, aboutContent },
  });

  // logoData 只在前端这次确实改了 logo（重新上传或点了移除）时才会出现在 body 里，
  // 没改动的话就不动 SiteAsset 这张表，避免每次保存设置都重写一遍图片数据。
  if ('logoData' in body) {
    await prisma.siteAsset.upsert({
      where: { id: 1 },
      update: { logoData: body.logoData },
      create: { id: 1, logoData: body.logoData },
    });
  }

  // layout 是所有页面共用的，type: 'layout' 会让所有路由的布局缓存一起失效，改完立即生效
  revalidatePath('/', 'layout');

  return NextResponse.json(settings);
}
