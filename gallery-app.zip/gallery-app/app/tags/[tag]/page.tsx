import { prisma } from '@/lib/db';
import { publicUrl } from '@/lib/r2';
import Link from 'next/link';
import Image from 'next/image';
import type { Metadata } from 'next';
import Pagination from '@/app/components/Pagination';
import { getPageParams, getTotalPages } from '@/lib/pagination';

export const revalidate = 3600;

export async function generateMetadata({
  params,
}: {
  params: Promise<{ tag: string }>;
}): Promise<Metadata> {
  const { tag } = await params;
  return { title: `标签：${tag}` };
}

export default async function TagPage({
  params,
  searchParams,
}: {
  params: Promise<{ tag: string }>;
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const { tag } = await params;
  const sp = await searchParams;
  const { page, skip, take } = getPageParams(sp);

  const where = { status: 'PUBLISHED' as const, tags: { has: tag } };

  const [albums, totalCount] = await Promise.all([
    prisma.album.findMany({
      where,
      orderBy: { publishedAt: 'desc' },
      skip,
      take,
      select: { title: true, slug: true, coverKey: true, coverBlurDataURL: true },
    }),
    prisma.album.count({ where }),
  ]);

  const totalPages = getTotalPages(totalCount);

  return (
    <div>
      <div className="flex items-center justify-between gap-2 px-4 py-4">
        <h1 className="text-lg text-[var(--fg-80)]">
          标签：<span className="text-[var(--text-color)]">{tag}</span>
        </h1>
        <Link href="/tags" className="text-sm text-[var(--fg-50)] hover:text-[var(--text-color)]">
          全部标签
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-x-1 gap-y-3 p-1 sm:grid-cols-3 md:grid-cols-4">
        {albums.map((album, index) => (
          <Link key={album.slug} href={`/albums/${album.slug}`} className="group block">
            <div className="relative aspect-square overflow-hidden bg-[var(--fg-5)]">
              {album.coverKey && (
                <Image
                  src={publicUrl(album.coverKey)}
                  alt={album.title}
                  fill
                  sizes="(max-width: 768px) 50vw, 25vw"
                  className="object-cover transition duration-500 group-hover:scale-105"
                  priority={index === 0}
                  loading={index === 0 ? undefined : 'lazy'}
                  {...(album.coverBlurDataURL
                    ? { placeholder: 'blur' as const, blurDataURL: album.coverBlurDataURL }
                    : {})}
                />
              )}
            </div>
            <p className="mt-1.5 truncate px-0.5 text-base text-[var(--fg-80)] group-hover:text-[var(--text-color)]">
              {album.title}
            </p>
          </Link>
        ))}
        {albums.length === 0 && (
          <p className="col-span-full p-8 text-center text-[var(--fg-50)]">这个标签下暂时没有图集</p>
        )}
      </div>

      <Pagination currentPage={page} totalPages={totalPages} basePath={`/tags/${encodeURIComponent(tag)}`} />
    </div>
  );
}
