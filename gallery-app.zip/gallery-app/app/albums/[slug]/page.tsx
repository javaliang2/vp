import { cache } from 'react';
import { prisma } from '@/lib/db';
import { publicUrl } from '@/lib/r2';
import Image from 'next/image';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { getSiteSettings } from '@/lib/settings';
import { siteUrl } from '@/lib/site-url';
import BackButton from '@/app/components/BackButton';
import ShareButton from '@/app/components/ShareButton';
import PhotoGallery from '@/app/components/PhotoGallery';

export const revalidate = 3600;

// 注意：这里故意不写 generateStaticParams。
// 如果加上它，`next build` 会在构建镜像的阶段就去查数据库拿所有图集 slug，
// 但 docker build 阶段 Postgres 服务通常还没起来（build 和 up 是两个独立阶段），
// 构建环境也不一定连得上数据库，容易导致镜像构建失败。
// 不写这个函数，页面照样是 ISR：第一次访问时按需生成 + 缓存，之后跟静态页一样快。

const getAlbum = cache(async (slug: string) => {
  return prisma.album.findUnique({
    where: { slug, status: 'PUBLISHED' },
    include: {
      photos: { orderBy: { sortOrder: 'asc' } },
      category: { select: { name: true, slug: true, parent: { select: { name: true, slug: true } } } },
    },
  });
});

// 上一个/下一个图集，按全局发布时间排序（跟首页默认顺序一致——首页是按发布时间从新到旧排的）。
// 所以"上一个"对应更新的那个，"下一个"对应更旧的那个，跟首页列表里的先后顺序保持一致。
// 没有区分当前分类，是因为详情页目前拿不到"访客是从哪个分类点进来的"这个上下文——
// 首页的链接是 /albums/slug，没带 ?category=，要做到"分类内穿梭"得先把这个上下文传过来。
async function getAdjacentAlbums(current: { publishedAt: Date | null; createdAt: Date }) {
  const cursor = current.publishedAt ?? current.createdAt;

  const [prev, next] = await Promise.all([
    prisma.album.findFirst({
      where: { status: 'PUBLISHED', publishedAt: { gt: cursor } },
      orderBy: { publishedAt: 'asc' },
      select: { slug: true, title: true, coverKey: true, coverBlurDataURL: true },
    }),
    prisma.album.findFirst({
      where: { status: 'PUBLISHED', publishedAt: { lt: cursor } },
      orderBy: { publishedAt: 'desc' },
      select: { slug: true, title: true, coverKey: true, coverBlurDataURL: true },
    }),
  ]);

  return { prev, next };
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const album = await getAlbum(slug);
  if (!album) return {};

  const settings = await getSiteSettings();
  const title = `${album.title} - ${settings.siteTitle}`;
  const description = album.description || settings.siteDescription;
  const cover = album.coverKey || album.photos[0]?.r2Key;
  const url = `${siteUrl()}/albums/${album.slug}`;

  return {
    title,
    description,
    alternates: { canonical: url },
    openGraph: {
      title,
      description,
      url,
      type: 'article',
      images: cover ? [{ url: publicUrl(cover) }] : undefined,
    },
    twitter: {
      card: cover ? 'summary_large_image' : 'summary',
      title,
      description,
      images: cover ? [publicUrl(cover)] : undefined,
    },
  };
}

export default async function AlbumPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const album = await getAlbum(slug);

  if (!album) notFound();

  const { prev, next } = await getAdjacentAlbums(album);

  return (
    <div id="top" className="mx-auto max-w-5xl px-4 py-8">
      {album.category && (
        <div className="flex items-center gap-1 text-sm uppercase tracking-wide text-[var(--fg-50)]">
          {album.category.parent && (
            <>
              <a href={`/?category=${album.category.parent.slug}`} className="hover:text-[var(--text-color)]">
                {album.category.parent.name}
              </a>
              <span>/</span>
            </>
          )}
          <a href={`/?category=${album.category.slug}`} className="hover:text-[var(--text-color)]">
            {album.category.name}
          </a>
        </div>
      )}
      <h1 className="mt-1 text-2xl font-medium">{album.title}</h1>
      {album.description && <p className="mt-2 text-[var(--fg-60)]">{album.description}</p>}
      {album.tags.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-2">
          {album.tags.map((tag) => (
            <span key={tag} className="rounded-full bg-[var(--fg-10)] px-3 py-1 text-xs">
              {tag}
            </span>
          ))}
        </div>
      )}

      <div className="mt-4 -ml-3">
        <ShareButton title={album.title} />
      </div>

      <PhotoGallery
        photos={album.photos.map((photo) => ({
          id: photo.id,
          url: publicUrl(photo.r2Key),
          width: photo.width,
          height: photo.height,
          alt: photo.altText || album.title,
          blurDataURL: photo.blurDataURL || undefined,
        }))}
      />

      <div className="mt-10 -mx-3 flex items-center justify-between gap-1 text-sm">
        <Link
          href="/"
          className="flex min-h-11 items-center gap-1 rounded px-3 text-[var(--fg-50)] hover:bg-[var(--fg-5)] hover:text-[var(--text-color)]"
        >
          <span aria-hidden>⌂</span> 首页
        </Link>

        <a
          href="#top"
          className="flex min-h-11 items-center gap-1 rounded px-3 text-[var(--fg-50)] hover:bg-[var(--fg-5)] hover:text-[var(--text-color)]"
        >
          <span aria-hidden>↑</span> 返回顶部
        </a>

        <BackButton />
      </div>

      <nav className="mt-4 grid grid-cols-2 gap-3 border-t border-[var(--fg-10)] pt-6">
          {prev ? (
            <Link href={`/albums/${prev.slug}`} className="group flex min-w-0 items-center gap-3 overflow-hidden">
              {prev.coverKey && (
                <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded bg-[var(--fg-5)]">
                  <Image
                    src={publicUrl(prev.coverKey)}
                    alt=""
                    fill
                    sizes="56px"
                    className="object-cover"
                    {...(prev.coverBlurDataURL
                      ? { placeholder: 'blur' as const, blurDataURL: prev.coverBlurDataURL }
                      : {})}
                  />
                </div>
              )}
              <div className="min-w-0">
                <p className="text-xs text-[var(--fg-50)]">上一个</p>
                <p className="truncate text-sm text-[var(--fg-80)] group-hover:text-[var(--text-color)]">
                  {prev.title}
                </p>
              </div>
            </Link>
          ) : (
            <div />
          )}

          {next ? (
            <Link
              href={`/albums/${next.slug}`}
              className="group flex min-w-0 items-center justify-end gap-3 overflow-hidden text-right"
            >
              <div className="min-w-0">
                <p className="text-xs text-[var(--fg-50)]">下一个</p>
                <p className="truncate text-sm text-[var(--fg-80)] group-hover:text-[var(--text-color)]">
                  {next.title}
                </p>
              </div>
              {next.coverKey && (
                <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded bg-[var(--fg-5)]">
                  <Image
                    src={publicUrl(next.coverKey)}
                    alt=""
                    fill
                    sizes="56px"
                    className="object-cover"
                    {...(next.coverBlurDataURL
                      ? { placeholder: 'blur' as const, blurDataURL: next.coverBlurDataURL }
                      : {})}
                  />
                </div>
              )}
            </Link>
          ) : (
            <div />
          )}
      </nav>

      {/* 浏览量埋点：客户端上报，不影响静态页缓存 */}
      <ViewTracker slug={album.slug} />
    </div>
  );
}

function ViewTracker({ slug }: { slug: string }) {
  return (
    <script
      dangerouslySetInnerHTML={{
        __html: `fetch('/api/albums/${slug}/view', { method: 'POST' }).catch(() => {});`,
      }}
    />
  );
}
