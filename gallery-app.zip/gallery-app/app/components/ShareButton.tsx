'use client';

import { useState } from 'react';

export default function ShareButton({ title }: { title: string }) {
  const [copied, setCopied] = useState(false);

  async function handleShare() {
    const url = window.location.href;

    // 手机浏览器大多支持系统分享面板，优先走这个
    if (navigator.share) {
      try {
        await navigator.share({ title, url });
      } catch {
        // 用户在系统分享面板里点了取消，navigator.share 也会 reject，这不是错误，什么都不用做
      }
      return;
    }

    // 桌面浏览器普遍没有 navigator.share，退化成复制链接
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // clipboard 也失败的话（比如非 HTTPS），没有更好的兜底了，静默失败
    }
  }

  return (
    <button
      type="button"
      onClick={handleShare}
      className="inline-flex min-h-9 items-center gap-1 rounded px-3 text-sm text-[var(--fg-50)] hover:bg-[var(--fg-5)] hover:text-[var(--text-color)]"
    >
      <span aria-hidden>⇪</span> {copied ? '已复制链接' : '分享'}
    </button>
  );
}
