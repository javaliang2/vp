import { prisma } from '@/lib/db';
import { publicUrl } from '@/lib/r2';
import Link from 'next/link';
import Image from 'next/image';
import type { Metadata } from 'next';
import Pagination from '@/app/components/Pagination';
import { getPageParams, getTotalPages } from '@/lib/pagination';

export const metadata: Metadata = { title: '搜索' };

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const params = await searchParams;
  const q = typeof params.q === 'string' ? params.q.trim() : '';
  const { page, skip, take } = getPageParams(params);

  const [albums, totalCount] = q
    ? await Promise.all([
        prisma.album.findMany({
          where: {
            status: 'PUBLISHED' as const,
            OR: [
              { title: { contains: q, mode: 'insensitive' as const } },
              { description: { contains: q, mode: 'insensitive' as const } },
              { tags: { has: q } },
            ],
          },
          orderBy: { publishedAt: 'desc' },
          skip,
          take,
          select: { title: true, slug: true, coverKey: true, coverBlurDataURL: true },
        }),
        prisma.album.count({
          where: {
            status: 'PUBLISHED' as const,
            OR: [
              { title: { contains: q, mode: 'insensitive' as const } },
              { description: { contains: q, mode: 'insensitive' as const } },
              { tags: { has: q } },
            ],
          },
        }),
      ])
    : [[], 0];

  const totalPages = getTotalPages(totalCount);

  return (
    <div>
      <form action="/search" className="px-4 py-6">
        <div className="mx-auto flex max-w-xl items-center gap-2 rounded-full border border-[var(--fg-10)] px-4 py-2.5">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true" className="shrink-0 text-[var(--fg-50)]">
            <circle cx="8" cy="8" r="5.5" stroke="currentColor" strokeWidth="1.6" />
            <line x1="12.2" y1="12.2" x2="16" y2="16" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          </svg>
          <input
            type="text"
            name="q"
            defaultValue={q}
            placeholder="搜索图集标题、简介或标签"
            autoFocus
            className="min-w-0 flex-1 bg-transparent text-sm text-[var(--text-color)] outline-none placeholder:text-[var(--fg-30)]"
          />
        </div>
      </form>

      {q ? (
        <>
          <div className="grid grid-cols-2 gap-x-1 gap-y-3 p-1 sm:grid-cols-3 md:grid-cols-4">
            {albums.map((album, index) => (
              <Link key={album.slug} href={`/albums/${album.slug}`} className="group block">
                <div className="relative aspect-square overflow-hidden bg-[var(--fg-5)]">
                  {album.coverKey && (
                    <Image
                      src={publicUrl(album.coverKey)}
                      alt={album.title}
                      fill
                      sizes="(max-width: 768px) 50vw, 25vw"
                      className="object-cover transition duration-500 group-hover:scale-105"
                      priority={index === 0}
                      loading={index === 0 ? undefined : 'lazy'}
                      {...(album.coverBlurDataURL
                        ? { placeholder: 'blur' as const, blurDataURL: album.coverBlurDataURL }
                        : {})}
                    />
                  )}
                </div>
                <p className="mt-1.5 truncate px-0.5 text-base text-[var(--fg-80)] group-hover:text-[var(--text-color)]">
                  {album.title}
                </p>
              </Link>
            ))}
            {albums.length === 0 && (
              <p className="col-span-full p-8 text-center text-[var(--fg-50)]">没找到和"{q}"相关的图集</p>
            )}
          </div>

          <Pagination currentPage={page} totalPages={totalPages} basePath="/search" extraParams={{ q }} />
        </>
      ) : (
        <p className="p-8 text-center text-[var(--fg-50)]">输入关键词看看有没有相关的图集</p>
      )}
    </div>
  );
}
