import { prisma } from '@/lib/db';

export type SiteSettings = {
  siteTitle: string;
  siteDescription: string;
  logoKey: string | null;
  backgroundColor: string;
  textColor: string;
  accentColor: string;
  icpNumber: string;
  contactInfo: string;
  aboutContent: string;
};

const DEFAULTS: SiteSettings = {
  siteTitle: 'Gallery',
  siteDescription: '一个简单的图集展示站',
  logoKey: null,
  backgroundColor: '#1e1e1e',
  textColor: '#f2f2f0',
  accentColor: '#ffffff',
  icpNumber: '',
  contactInfo: '',
  aboutContent: '',
};

export async function getSiteSettings(): Promise<SiteSettings> {
  try {
    const row = await prisma.siteSetting.findUnique({ where: { id: 1 } });
    return row ? { ...DEFAULTS, ...row } : DEFAULTS;
  } catch {
    // 数据库还没跑迁移，或者查询失败时兜底，不影响页面渲染
    return DEFAULTS;
  }
}
