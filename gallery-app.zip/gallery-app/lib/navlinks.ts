import { prisma } from '@/lib/db';

export type NavLinkItem = {
  id: string;
  label: string;
  url: string;
  newTab: boolean;
};

// 跟写入端（app/api/admin/navlinks/route.ts）保持一致的协议白名单。
// 这里再校验一遍是图个保险：万一之前有脏数据、或者以后又加了别的写入路径忘了校验，
// 前台渲染这一步兜底把危险协议换成 '#'，不会真的把 javascript:/data: 之类的链接吐给访客。
function isAllowedUrl(url: string): boolean {
  if (url.startsWith('/')) return true;
  return /^(https?:|mailto:|tel:)/i.test(url);
}

export async function getNavLinks(): Promise<NavLinkItem[]> {
  try {
    const links = await prisma.navLink.findMany({
      orderBy: { sortOrder: 'asc' },
      select: {
        id: true,
        label: true,
        url: true,
        newTab: true,
        category: { select: { slug: true } },
      },
    });
    return links.map((link) => {
      const rawUrl = link.category ? `/?category=${link.category.slug}` : link.url ?? '#';
      return {
        id: link.id,
        label: link.label,
        url: isAllowedUrl(rawUrl) ? rawUrl : '#',
        newTab: link.newTab,
      };
    });
  } catch {
    // 数据库还没跑迁移，或者查询失败时兜底为空菜单，不影响页面渲染
    return [];
  }
}
